#!/bin/bash

# Load environnement varaibles
. ./env.sh
. ./certs.sh

#MASTER
echo '************************ START ' $PREFIX ' POD WATCHER ************************'
if [[ $createdcppodwatcher == "true" ]]; then
    if kubectl get sts $releasemasterpodwatcher -n $NAMESPACE &> /dev/null; then
        echo '============================= ' $PREFIX ' POD WATCHER ALREADY INSTALLED ============================='
    else
        echo '=================================== CREATING' $PREFIX  ' POD WATCHER ==================================='
        sed -e "s#{{PODWATCHER_NAME}}#$PODWATCHER_NAME-$1#g;\
        s#{{NAMESPACE}}#$NAMESPACE#g;\
        s#{{CLUSTERDOMAIN}}#$CLUSTERDOMAIN#g;\
        s#{{STORAGECLASSNAME}}#$STORAGECLASSNAME#g;\
        s#{{SECRETNAME}}#$SECRETNAME#g;\
        s#{{ISOPENSHIFT}}#$ISOPENSHIFT#g;\
        s#{{PODWATCHER_LOGLEVEL}}#$PODWATCHER_LOGLEVEL#g;\
        s#{{WATCHERNAME}}#$1#g;\
        s#{{IMAGEPULLSECRET}}#$IMAGEPULLSECRET#g;\
        s#{{REGISTRY}}#$REGISTRY#g;\
        s#{{PGS_REPLICATION_REPOSITORY}}#$PGS_REPLICATION_REPOSITORY#g;\
        s#{{PODWATCHER_REPOSITORY}}#$PODWATCHER_REPOSITORY#g;\
        s#{{PGS_REPLICATION_VERSION}}#$PGS_REPLICATION_VERSION#g;\
        s#{{PULLPOLICY}}#$PULLPOLICY#g;\
        s#{{PODWATCHER_VERSION}}#$PODWATCHER_VERSION#g;\
        s#{{COMMONLABELS}}#$COMMONLABELS#g;\
        s#{{COMMONANNOTATIONS}}#$COMMONANNOTATIONS#g;\
        s#{{MASTER_HOSTALIASES}}#$MASTER_HOSTALIASES#g;\
        s#{{MASTER_DNSCONFIG}}#$MASTER_DNSCONFIG#g;\
        s#{{RUNASUSER}}#$RUNASUSER#g;\
        s#{{READONLYROOTFILESYSTEM}}#$READONLYROOTFILESYSTEM#g;\
        s#{{PODWATCHER_SERVICE_ACCOUNT}}#$PODWATCHER_SERVICE_ACCOUNT-$1#g;\
        s#{{PODWATCHER_CLUSTER_ROLE}}#$PODWATCHER_CLUSTER_ROLE#g;\
        s#{{MASTER_NAMESPACES}}#$MASTER_NAMESPACES#g;\
        s#{{PODWATCHER_PORT}}#$PODWATCHER_PORT#g;\
        s#{{PGS_USERNAME}}#$PGS_USERNAME#g;\
        s#{{PGS_PASSWORD}}#$PGS_PASSWORD#g;\
        s#{{PGS_DATABASE}}#$PGS_DATABASE#g;\
        s#{{MASTER_PGS_CONNECTION_TIMEOUT}}#$MASTER_PGS_CONNECTION_TIMEOUT#g;\
        s#{{MASTER_PGS_MINIMUMIDLE}}#$MASTER_PGS_MINIMUMIDLE#g;\
        s#{{MASTER_PGS_MAXIMUMPOOLSIZE}}#$MASTER_PGS_MAXIMUMPOOLSIZE#g;\
        s#{{MASTER_PGS_IDLETIMEOUT}}#$MASTER_PGS_IDLETIMEOUT#g;\
        s#{{MASTER_PGS_MAXLIFETIME}}#$MASTER_PGS_MAXLIFETIME#g;\
        s#{{MASTER_PGS_AUTOCOMMIT}}#$MASTER_PGS_AUTOCOMMIT#g;\
        s#{{PGS_SERVICENAME}}#$PGS_SERVICENAME#g;\
        s#{{PODWATCHER_XMS}}#$PODWATCHER_XMS#g;\
        s#{{PODWATCHER_XMX}}#$PODWATCHER_XMX#g;\
        s#{{PODWATCHER_SERVICENAME}}#$PODWATCHER_SERVICENAME#g;\
        s#{{PODWATCHER_REQUESTCPU}}#$PODWATCHER_REQUESTCPU#g;\
        s#{{PODWATCHER_REQUESTMEMORY}}#$PODWATCHER_REQUESTMEMORY#g;\
        s#{{PODWATCHER_LIMITCPU}}#$PODWATCHER_LIMITCPU#g;\
        s#{{PODWATCHER_CLEANPODS}}#$PODWATCHER_CLEANPODS#g;\
        s#{{MASTER_CLUSTER_ROLE}}#$MASTER_CLUSTER_ROLE#g;\
        s#{{PODWATCHER_NAMESPACES}}#$PODWATCHER_NAMESPACES#g;\
        s#{{PODWATCHER_LIMITMEMORY}}#$PODWATCHER_LIMITMEMORY#g;" $yamltemplate/master-podwatcher-template.yaml > $yamldestination/master-podwatcher-$1.yaml

        if [[ $template == "false" ]]; then
            helm -n $NAMESPACE upgrade --cleanup-on-fail --install $releasemasterpodwatcher-$1 $repodir/master-podwatcher --values $yamldestination/master-podwatcher-$1.yaml
        fi
        #kubectl -n $NAMESPACE wait --for=condition=available --timeout=600s deployment.apps/master-proxy
        echo '=================================== ' $PREFIX  ' POD WATCHER CREATED ==================================='
    fi
else
    echo '=================================== ' $PREFIX  ' POD WATCHER DISABLED==================================='
fi

echo '************************ END ' $PREFIX ' POD WATCHER ************************'
echo ''
echo ''