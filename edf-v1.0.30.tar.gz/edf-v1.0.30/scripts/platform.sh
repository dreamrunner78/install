#!/bin/bash

./00-storage.sh
./01-namespace.sh
./02-secrets.sh
./03-logstack.sh
./04-redis.sh
./05-scheduler.sh
./06-proxy.sh
./07-database.sh
./08-initdatabase.sh
./09-api.sh
./10-logwatcher.sh
./11-podwatcher.sh primary
./11-podwatcher.sh secondary
./11-podwatcher.sh backup
./12-health.sh
./13-sqlactivity.sh