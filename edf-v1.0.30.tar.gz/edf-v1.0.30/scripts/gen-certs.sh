#!/bin/bash

. ./env.sh

CACERT=$(kubectl -n $NAMESPACE get secret $SECRETNAME -o json | jq -r '.data["ca.crt"]' | base64 --decode)
CAKEY=$(kubectl -n $NAMESPACE get secret $SECRETNAME -o json | jq -r '.data["ca.key"]' | base64 --decode)
TLSCERT=$(kubectl -n $NAMESPACE get secret $SECRETNAME -o json | jq -r '.data["tls.crt"]' | base64 --decode)
TLSKEY=$(kubectl -n $NAMESPACE get secret $SECRETNAME -o json | jq -r '.data["tls.key"]' | base64 --decode)
KEYCLOAKCERT=$(kubectl -n $NAMESPACE get secret $SECRETNAME -o json | jq -r '.data["keycloak.crt"]' | base64 --decode)
KEYCLOAKKEY=$(kubectl -n $NAMESPACE get secret $SECRETNAME -o json | jq -r '.data["keycloak.key"]' | base64 --decode)

echo "$CACERT" | while IFS= read -r line; do
    echo "$line" >> certs/ca.crt
done
echo "$CAKEY" | while IFS= read -r line; do
    echo "$line" >> certs/ca.key
done

echo "$TLSCERT" | while IFS= read -r line; do
    echo "$line" >> certs/tls.crt
done
echo "$TLSKEY" | while IFS= read -r line; do
    echo "$line" >> certs/tls.key
done


echo "$KEYCLOAKCERT" | while IFS= read -r line; do
    echo "$line" >> certs/keycloak.crt
done
echo "$KEYCLOAKKEY" | while IFS= read -r line; do
    echo "$line" >> certs/keycloak.key
done