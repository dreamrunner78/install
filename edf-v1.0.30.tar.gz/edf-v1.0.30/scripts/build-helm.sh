cd /Users/bassim/Documents/Platform/Dockers/files/dcp-api

helm package /Users/bassim/Documents/dcp-setup/repos/dcp-airflow

helm package /Users/bassim/Documents/dcp-setup/repos/dcp-keycloak

helm package /Users/bassim/Documents/dcp-setup/repos/dcp-metastore
helm package /Users/bassim/Documents/dcp-setup/repos/dcp-solr
helm package /Users/bassim/Documents/dcp-setup/repos/dcp-ranger
helm package /Users/bassim/Documents/dcp-setup/repos/dcp-sql

helm package /Users/bassim/Documents/dcp-setup/repos/dcp-proxy-appli

helm package /Users/bassim/Documents/dcp-setup/repos/dcp-spark-cluster
helm package /Users/bassim/Documents/dcp-setup/repos/dcp-spark-monitoring
helm package /Users/bassim/Documents/dcp-setup/repos/dcp-spark-history
helm package /Users/bassim/Documents/dcp-setup/repos/dcp-single-notebook
helm package /Users/bassim/Documents/dcp-setup/repos/dcp-spark-operator

helm package /Users/bassim/Documents/dcp-setup/repos/dcp-nifi

helm package /Users/bassim/Documents/dcp-setup/repos/dcp-scheduler