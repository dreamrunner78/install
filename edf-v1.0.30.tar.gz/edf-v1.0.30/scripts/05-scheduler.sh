#!/bin/bash

# Load environnement varaibles
. ./env.sh
. ./certs.sh



# SCHEDULER
echo '************************ START ' $PREFIX ' SCHEDULER ************************'
if [[ $createdcpscheduler == "true" ]]; then
    if kubectl get deploy $releasescheduler -n $NAMESPACE &> /dev/null; then
        echo "=============================' $PREFIX ' SCHEDULER ALREADY INSTALLED ============================="
    else
        echo '=================================== CREATING' $PREFIX  ' SCHEDULER ==================================='
        sed -e "s#{{RUNASUSER}}#$RUNASUSER#g;\
        s#{{REGISTRY}}#$REGISTRY#g;\
        s#{{READONLYROOTFILESYSTEM}}#$READONLYROOTFILESYSTEM#g;\
        s#{{COMMONLABELS}}#$COMMONLABELS#g;\
        s#{{COMMONANNOTATIONS}}#$COMMONANNOTATIONS#g;\
        s#{{PULLPOLICY}}#$PULLPOLICY#g;\
        s#{{SECRETNAME}}#$SECRETNAME#g;\
        s#{{IMAGEPULLSECRET}}#$IMAGEPULLSECRET#g;\
        s#{{releasescheduler}}#$releasescheduler#g;\
        
        
        s#{{ADMISSION_REPOSITORY}}#$ADMISSION_REPOSITORY#g;\
        s#{{ADMISSION_VERSION}}#$ADMISSION_VERSION#g;\
        s#{{ADMISSION_REQUESTCPU}}#$ADMISSION_REQUESTCPU#g;\
        s#{{ADMISSION_LIMITCPU}}#$ADMISSION_LIMITCPU#g;\
        s#{{ADMISSION_REQUESTMEMORY}}#$ADMISSION_REQUESTMEMORY#g;\
        s#{{ADMISSION_LIMITMEMORY}}#$ADMISSION_LIMITMEMORY#g;\
        
        s#{{PLUGIN_REPOSITORY}}#$PLUGIN_REPOSITORY#g;\
        s#{{PLUGIN_VERSION}}#$PLUGIN_VERSION#g;\

        s#{{WEB_REPOSITORY}}#$WEB_REPOSITORY#g;\
        s#{{WEB_VERSION}}#$WEB_VERSION#g;\
        s#{{WEB_REQUESTCPU}}#$WEB_REQUESTCPU#g;\
        s#{{WEB_LIMITCPU}}#$WEB_LIMITCPU#g;\
        s#{{WEB_REQUESTMEMORY}}#$WEB_REQUESTMEMORY#g;\
        s#{{WEB_LIMITMEMORY}}#$WEB_LIMITMEMORY#g;\
        
        s#{{SCHEDULER_REPOSITORY}}#$SCHEDULER_REPOSITORY#g;\
        s#{{SCHEDULER_VERSION}}#$SCHEDULER_VERSION#g;\
        s#{{SCHEDULER_REQUESTCPU}}#$SCHEDULER_REQUESTCPU#g;\
        s#{{SCHEDULER_LIMITCPU}}#$SCHEDULER_LIMITCPU#g;\
        s#{{SCHEDULER_REQUESTMEMORY}}#$SCHEDULER_REQUESTMEMORY#g;\
        s#{{SCHEDULER_LIMITMEMORY}}#$SCHEDULER_LIMITMEMORY#g;\
        s#{{SCHEDULER_ENABLEOSROOT}}#$SCHEDULER_ENABLEOSROOT#g;\
        s#{{SCHEDULER_ENABLEINGRESS}}#$SCHEDULER_ENABLEINGRESS#g;\
        s#{{SCHEDULER_INGRESSHOSTNAME}}#$SCHEDULER_INGRESSHOSTNAME#g" $yamltemplate/scheduler-template.yaml > $yamldestination/scheduler.yaml
        
        if [[ $template == "false" ]]; then
            helm -n $NAMESPACE upgrade --cleanup-on-fail --install $releasescheduler $repodir/scheduler --values $yamldestination/scheduler.yaml
        fi

        echo '===================================' $PREFIX ' SCHEDULER CREATED ==================================='
    fi
else
    echo '===================================' $PREFIX ' SCHEDULER DISABLED ==================================='
fi

echo '************************ END ' $PREFIX ' SCHEDULER ************************'