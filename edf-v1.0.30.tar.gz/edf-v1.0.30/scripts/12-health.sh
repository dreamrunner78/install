#!/bin/bash

# Load environnement varaibles
. ./env.sh
. ./certs.sh

#MASTER
echo '************************ START ' $PREFIX ' HEALTH ************************'
if [[ $createdcpheath == "true" ]]; then
    if kubectl get sts $releasemasterhealth -n $NAMESPACE &> /dev/null; then
        echo '============================= ' $PREFIX ' HEALTH ALREADY INSTALLED ============================='
    else
        echo '=================================== CREATING' $PREFIX  ' HEALTH ==================================='
        sed -e "s#{{HEALTH_NAME}}#$HEALTH_NAME#g;\
        s#{{NAMESPACE}}#$NAMESPACE#g;\
        s#{{CLUSTERDOMAIN}}#$CLUSTERDOMAIN#g;\
        s#{{STORAGECLASSNAME}}#$STORAGECLASSNAME#g;\
        s#{{SECRETNAME}}#$SECRETNAME#g;\
        s#{{ISOPENSHIFT}}#$ISOPENSHIFT#g;\
        s#{{HEALTH_LOGLEVEL}}#$HEALTH_LOGLEVEL#g;\
        s#{{WATCHERNAME}}#$1#g;\
        s#{{IMAGEPULLSECRET}}#$IMAGEPULLSECRET#g;\
        s#{{REGISTRY}}#$REGISTRY#g;\
        s#{{PGS_REPLICATION_REPOSITORY}}#$PGS_REPLICATION_REPOSITORY#g;\
        s#{{PGS_REPLICATION_VERSION}}#$PGS_REPLICATION_VERSION#g;\
        s#{{HEALTH_REPOSITORY}}#$HEALTH_REPOSITORY#g;\
        s#{{PULLPOLICY}}#$PULLPOLICY#g;\
        s#{{HEALTH_VERSION}}#$HEALTH_VERSION#g;\
        s#{{COMMONLABELS}}#$COMMONLABELS#g;\
        s#{{COMMONANNOTATIONS}}#$COMMONANNOTATIONS#g;\
        s#{{MASTER_HOSTALIASES}}#$MASTER_HOSTALIASES#g;\
        s#{{MASTER_DNSCONFIG}}#$MASTER_DNSCONFIG#g;\
        s#{{RUNASUSER}}#$RUNASUSER#g;\
        s#{{READONLYROOTFILESYSTEM}}#$READONLYROOTFILESYSTEM#g;\
        s#{{HEALTH_SERVICE_ACCOUNT}}#$HEALTH_SERVICE_ACCOUNT#g;\
        s#{{HEALTH_CLUSTER_ROLE}}#$HEALTH_CLUSTER_ROLE#g;\
        s#{{MASTER_NAMESPACES}}#$MASTER_NAMESPACES#g;\
        s#{{HEALTH_PORT}}#$HEALTH_PORT#g;\
        s#{{PGS_USERNAME}}#$PGS_USERNAME#g;\
        s#{{PGS_PASSWORD}}#$PGS_PASSWORD#g;\
        s#{{PGS_DATABASE}}#$PGS_DATABASE#g;\
        s#{{MASTER_PGS_CONNECTION_TIMEOUT}}#$MASTER_PGS_CONNECTION_TIMEOUT#g;\
        s#{{MASTER_PGS_MINIMUMIDLE}}#$MASTER_PGS_MINIMUMIDLE#g;\
        s#{{MASTER_PGS_MAXIMUMPOOLSIZE}}#$MASTER_PGS_MAXIMUMPOOLSIZE#g;\
        s#{{MASTER_PGS_IDLETIMEOUT}}#$MASTER_PGS_IDLETIMEOUT#g;\
        s#{{MASTER_PGS_MAXLIFETIME}}#$MASTER_PGS_MAXLIFETIME#g;\
        s#{{MASTER_PGS_AUTOCOMMIT}}#$MASTER_PGS_AUTOCOMMIT#g;\
        s#{{PGS_SERVICENAME}}#$PGS_SERVICENAME#g;\
        s#{{HEALTH_XMS}}#$HEALTH_XMS#g;\
        s#{{HEALTH_XMX}}#$HEALTH_XMX#g;\
        s#{{HEALTH_SERVICENAME}}#$HEALTH_SERVICENAME#g;\
        s#{{HEALTH_REQUESTCPU}}#$HEALTH_REQUESTCPU#g;\
        s#{{HEALTH_REQUESTMEMORY}}#$HEALTH_REQUESTMEMORY#g;\
        s#{{HEALTH_LIMITCPU}}#$HEALTH_LIMITCPU#g;\
        s#{{HEALTH_HEARTBEAT}}#$HEALTH_HEARTBEAT#g;\
        s#{{HEALTH_DELAY}}#$HEALTH_DELAY#g;\
        s#{{HEALTH_LIMITMEMORY}}#$HEALTH_LIMITMEMORY#g;" $yamltemplate/master-health-template.yaml > $yamldestination/master-health.yaml

        if [[ $template == "false" ]]; then
            helm -n $NAMESPACE upgrade --cleanup-on-fail --install $releasemasterhealth $repodir/master-health --values $yamldestination/master-health.yaml
        fi
        #kubectl -n $NAMESPACE wait --for=condition=available --timeout=600s deployment.apps/master-proxy
        echo '=================================== ' $PREFIX  ' HEALTH CREATED ==================================='
    fi
else
    echo '=================================== ' $PREFIX  ' HEALTH DISABLED==================================='
fi

echo '************************ END ' $PREFIX ' HEALTH ************************'
echo ''
echo ''