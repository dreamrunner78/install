from airflow import DAG
from datetime import datetime, timedelta
from airflow.contrib.operators.kubernetes_pod_operator import KubernetesPodOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.providers.trino.operators.trino import TrinoOperator
from kubernetes.client import models as k8s
from airflow.utils.task_group import TaskGroup

# START HEADER
compute_resources_job01_rajcwd=k8s.V1ResourceRequirements(
    requests={
        'cpu': '100m',
        'memory': '128Mi'
    },
    limits={
        'cpu': '500m',
        'memory': '512Mi'
    }
)

#SPARK TEMPLATE
vm_sparktemplate_job01_rajcwd = k8s.V1VolumeMount(
  mount_path="/opt/spark/template", 
  name="sparktemplate", 
  sub_path=None, 
  read_only=False
)
v_sparktemplate_tmp_job01_rajcwd = k8s.V1Volume(
    name="sparktemplate",
    empty_dir=k8s.V1EmptyDirVolumeSource()
)

#PASSWD
volume_config_passwd_job01_rajcwd = k8s.V1ConfigMapVolumeSource(
  name='master-passwd-job01-cm'
)
volume_mount_passwd_job01_rajcwd = k8s.V1VolumeMount(
  mount_path='/etc/passwd', 
  name='passwd', 
  sub_path='passwd', 
  read_only=False
)
volume_passwd_job01_rajcwd = k8s.V1Volume(
    name='passwd', 
    config_map=volume_config_passwd_job01_rajcwd
)

#TMP DIRECTORY
volume_mount_tmpdir_job01_rajcwd = k8s.V1VolumeMount(
  mount_path="/tmp", 
  name="tmp", 
  sub_path=None, 
  read_only=False
)
volume_tmpdir_job01_rajcwd = k8s.V1Volume(
    name="tmp",
    empty_dir=k8s.V1EmptyDirVolumeSource()
)
#FINAL CACERT
volume_mount_finalcacert_job01_rajcwd = k8s.V1VolumeMount(
  mount_path="/opt/finalcacert", 
  name="finalcacert", 
  sub_path=None, 
  read_only=False
)
volume_finalcacet_job01_rajcwd = k8s.V1Volume(
    name="finalcacert",
    empty_dir=k8s.V1EmptyDirVolumeSource()
)

#CERTIFICATE CONFIGMAP
volume_config_cert_job01_rajcwd = k8s.V1ConfigMapVolumeSource(
  name='master-addcert-job01-cm'
)
volume_mount_cert_rajcwd = k8s.V1VolumeMount(
  mount_path='/opt/addcert', 
  name='addcert',
  read_only=False
)
volume_cert_job01_rajcwd = k8s.V1Volume(
    name='addcert', 
    config_map=volume_config_cert_job01_rajcwd
)

init_container_dndnode_3 = k8s.V1Container(
    name="master-spark-template-job01-rajcwd",
    image="docker.io/dcptechnologies/spark:350-j17p3h3",
    volume_mounts=[vm_sparktemplate_job01_rajcwd, volume_mount_cert_rajcwd, volume_mount_finalcacert_job01_rajcwd],
    command=["sh", "-c"],
    args=["""
cp $JAVA_HOME/lib/security/cacerts /opt/finalcacert/cacerts
chmod 777 /opt/finalcacert/cacerts
keytool -import -noprompt -trustcacerts -alias storage_3 -file /opt/addcert/storage_3 -keystore /opt/finalcacert/cacerts -storepass changeit
cat << EOF > /opt/spark/template/driver.yaml
apiVersion: v1
kind: Pod       
metadata:
  annotations:
spec:
  schedulerName: ""
  priorityClassName: ""
  volumes:
    - name: passwd
      configMap:
        name: master-passwd-job01-cm
    - name: finalcacert
      emptyDir: {}
    - name: addcert
      configMap:
        name: master-addcert-job01-cm

  securityContext:
    runAsNonRoot: true
    runAsUser: 7000
    fsGroup: 7000
  initContainers:
    - name: master-job01-ic-driver-rajcwd
      image: docker.io/dcptechnologies/java:17-jre
      imagePullPolicy: "IfNotPresent"
      command:
        - sh
        - -c
        - |
          cp $JAVA_HOME/lib/security/cacerts /opt/finalcacert/cacerts
          chmod 777 /opt/finalcacert/cacerts
          keytool -import -noprompt -trustcacerts -alias master-storage_3 -file /opt/addcert/storage_3 -keystore /opt/finalcacert/cacerts -storepass changeit
      securityContext:
        runAsNonRoot: true
        runAsUser: 7000
        allowPrivilegeEscalation: false
        seccompProfile:
          type: RuntimeDefault
        capabilities:
          drop: ["ALL"]
      volumeMounts:
        - name: finalcacert
          mountPath: /opt/finalcacert
        - name: addcert
          mountPath: /opt/addcert
  containers:
    - name: master-job01-c-driver-rajcwd
      securityContext:
        runAsNonRoot: true
        runAsUser: 7000
        allowPrivilegeEscalation: false
        seccompProfile:
          type: RuntimeDefault
        capabilities:
          drop: ["ALL"]
      env:
      volumeMounts:
        - name:  finalcacert
          mountPath: /opt/finalcacert
        - name: addcert
          mountPath: /opt/addcert
        - name: passwd
          mountPath: /etc/passwd
          subPath: passwd
EOF
cat << EOF > /opt/spark/template/executor.yaml
apiVersion: v1
kind: Pod
metadata:    
  annotations:
spec:
  schedulerName: ""
  volumes:
    - name: passwd
      configMap:
        name: master-passwd-job01-cm
    - name: finalcacert
      emptyDir: {}
    - name: addcert
      configMap:
        name: master-addcert-job01-cm

  securityContext:
    runAsNonRoot: true
    runAsUser: 7000
    fsGroup: 7000
  initContainers:
    - name: master-job01-ic-exec-rajcwd
      image: docker.io/dcptechnologies/java:17-jre
      imagePullPolicy: "IfNotPresent"
      command:
        - sh
        - -c
        - |
          cp $JAVA_HOME/lib/security/cacerts /opt/finalcacert/cacerts
          chmod 777 /opt/finalcacert/cacerts
          keytool -import -noprompt -trustcacerts -alias master-storage_3 -file /opt/addcert/storage_3 -keystore /opt/finalcacert/cacerts -storepass changeit
      securityContext:
        runAsNonRoot: true
        runAsUser: 7000
        allowPrivilegeEscalation: false
        seccompProfile:
          type: RuntimeDefault
        capabilities:
          drop: ["ALL"]
      volumeMounts:
        - name: finalcacert
          mountPath: /opt/finalcacert
        - name: addcert
          mountPath: /opt/addcert
  containers:
    - name: master-job01-exec-c-rajcwd
      securityContext:
        runAsNonRoot: true
        runAsUser: 7000
        allowPrivilegeEscalation: false
        seccompProfile:
          type: RuntimeDefault
        capabilities:
          drop: ["ALL"]
      env:
      volumeMounts:
        - name:  finalcacert
          mountPath: /opt/finalcacert
        - name: addcert
          mountPath: /opt/addcert
        - name: passwd
          mountPath: /etc/passwd
          subPath: passwd
EOF
    """],
)
compute_resources_pysparkenv_thbljv=k8s.V1ResourceRequirements(
    requests={
        'cpu': '100m',
        'memory': '128Mi'
    },
    limits={
        'cpu': '500m',
        'memory': '512Mi'
    }
)

#SPARK TEMPLATE
vm_sparktemplate_pysparkenv_thbljv = k8s.V1VolumeMount(
  mount_path="/opt/spark/template", 
  name="sparktemplate", 
  sub_path=None, 
  read_only=False
)
v_sparktemplate_tmp_pysparkenv_thbljv = k8s.V1Volume(
    name="sparktemplate",
    empty_dir=k8s.V1EmptyDirVolumeSource()
)

#PASSWD
volume_config_passwd_pysparkenv_thbljv = k8s.V1ConfigMapVolumeSource(
  name='master-passwd-pysparkenv-cm'
)
volume_mount_passwd_pysparkenv_thbljv = k8s.V1VolumeMount(
  mount_path='/etc/passwd', 
  name='passwd', 
  sub_path='passwd', 
  read_only=False
)
volume_passwd_pysparkenv_thbljv = k8s.V1Volume(
    name='passwd', 
    config_map=volume_config_passwd_pysparkenv_thbljv
)

#TMP DIRECTORY
volume_mount_tmpdir_pysparkenv_thbljv = k8s.V1VolumeMount(
  mount_path="/tmp", 
  name="tmp", 
  sub_path=None, 
  read_only=False
)
volume_tmpdir_pysparkenv_thbljv = k8s.V1Volume(
    name="tmp",
    empty_dir=k8s.V1EmptyDirVolumeSource()
)
#FINAL CACERT
volume_mount_finalcacert_pysparkenv_thbljv = k8s.V1VolumeMount(
  mount_path="/opt/finalcacert", 
  name="finalcacert", 
  sub_path=None, 
  read_only=False
)
volume_finalcacet_pysparkenv_thbljv = k8s.V1Volume(
    name="finalcacert",
    empty_dir=k8s.V1EmptyDirVolumeSource()
)

#CERTIFICATE CONFIGMAP
volume_config_cert_pysparkenv_thbljv = k8s.V1ConfigMapVolumeSource(
  name='master-addcert-pysparkenv-cm'
)
volume_mount_cert_thbljv = k8s.V1VolumeMount(
  mount_path='/opt/addcert', 
  name='addcert',
  read_only=False
)
volume_cert_pysparkenv_thbljv = k8s.V1Volume(
    name='addcert', 
    config_map=volume_config_cert_pysparkenv_thbljv
)

init_container_dndnode_5 = k8s.V1Container(
    name="master-spark-template-pysparkenv-thbljv",
    image="docker.io/dcptechnologies/spark:350-j17p3h3",
    volume_mounts=[vm_sparktemplate_pysparkenv_thbljv, volume_mount_cert_thbljv, volume_mount_finalcacert_pysparkenv_thbljv],
    command=["sh", "-c"],
    args=["""
cp $JAVA_HOME/lib/security/cacerts /opt/finalcacert/cacerts
chmod 777 /opt/finalcacert/cacerts
keytool -import -noprompt -trustcacerts -alias storage_3 -file /opt/addcert/storage_3 -keystore /opt/finalcacert/cacerts -storepass changeit
cat << EOF > /opt/spark/template/driver.yaml
apiVersion: v1
kind: Pod       
metadata:
  annotations:
spec:
  schedulerName: ""
  priorityClassName: ""
  volumes:
    - name: passwd
      configMap:
        name: master-passwd-pysparkenv-cm
    - name: finalcacert
      emptyDir: {}
    - name: addcert
      configMap:
        name: master-addcert-pysparkenv-cm

  securityContext:
    runAsNonRoot: true
    runAsUser: 7000
    fsGroup: 7000
  initContainers:
    - name: master-pysparkenv-ic-driver-thbljv
      image: docker.io/dcptechnologies/java:17-jre
      imagePullPolicy: "IfNotPresent"
      command:
        - sh
        - -c
        - |
          cp $JAVA_HOME/lib/security/cacerts /opt/finalcacert/cacerts
          chmod 777 /opt/finalcacert/cacerts
          keytool -import -noprompt -trustcacerts -alias master-storage_3 -file /opt/addcert/storage_3 -keystore /opt/finalcacert/cacerts -storepass changeit
      securityContext:
        runAsNonRoot: true
        runAsUser: 7000
        allowPrivilegeEscalation: false
        seccompProfile:
          type: RuntimeDefault
        capabilities:
          drop: ["ALL"]
      volumeMounts:
        - name: finalcacert
          mountPath: /opt/finalcacert
        - name: addcert
          mountPath: /opt/addcert
  containers:
    - name: master-pysparkenv-c-driver-thbljv
      securityContext:
        runAsNonRoot: true
        runAsUser: 7000
        allowPrivilegeEscalation: false
        seccompProfile:
          type: RuntimeDefault
        capabilities:
          drop: ["ALL"]
      env:
      volumeMounts:
        - name:  finalcacert
          mountPath: /opt/finalcacert
        - name: addcert
          mountPath: /opt/addcert
        - name: passwd
          mountPath: /etc/passwd
          subPath: passwd
EOF
cat << EOF > /opt/spark/template/executor.yaml
apiVersion: v1
kind: Pod
metadata:    
  annotations:
spec:
  schedulerName: ""
  volumes:
    - name: passwd
      configMap:
        name: master-passwd-pysparkenv-cm
    - name: finalcacert
      emptyDir: {}
    - name: addcert
      configMap:
        name: master-addcert-pysparkenv-cm

  securityContext:
    runAsNonRoot: true
    runAsUser: 7000
    fsGroup: 7000
  initContainers:
    - name: master-pysparkenv-ic-exec-thbljv
      image: docker.io/dcptechnologies/java:17-jre
      imagePullPolicy: "IfNotPresent"
      command:
        - sh
        - -c
        - |
          cp $JAVA_HOME/lib/security/cacerts /opt/finalcacert/cacerts
          chmod 777 /opt/finalcacert/cacerts
          keytool -import -noprompt -trustcacerts -alias master-storage_3 -file /opt/addcert/storage_3 -keystore /opt/finalcacert/cacerts -storepass changeit
      securityContext:
        runAsNonRoot: true
        runAsUser: 7000
        allowPrivilegeEscalation: false
        seccompProfile:
          type: RuntimeDefault
        capabilities:
          drop: ["ALL"]
      volumeMounts:
        - name: finalcacert
          mountPath: /opt/finalcacert
        - name: addcert
          mountPath: /opt/addcert
  containers:
    - name: master-pysparkenv-exec-c-thbljv
      securityContext:
        runAsNonRoot: true
        runAsUser: 7000
        allowPrivilegeEscalation: false
        seccompProfile:
          type: RuntimeDefault
        capabilities:
          drop: ["ALL"]
      env:
      volumeMounts:
        - name:  finalcacert
          mountPath: /opt/finalcacert
        - name: addcert
          mountPath: /opt/addcert
        - name: passwd
          mountPath: /etc/passwd
          subPath: passwd
EOF
    """],
)
# END HEADER

default_args = {
    'owner': 'dcp',
    'depends_on_past': True,    
    'start_date': datetime(2023, 1, 1),
    'retries': 1,
    'retry_delay': timedelta(minutes=10),
}
with DAG(
    dag_id='workflow_pip01', 
    default_args=default_args,
    schedule_interval=None,
    catchup=False) as dag:

# START TASK
    dndnode_1= DummyOperator(task_id='dndnode_1', dag=dag)
    dndnode_2= DummyOperator(task_id='dndnode_2', dag=dag)
    dndnode_3 = KubernetesPodOperator(namespace='demo',
    image="docker.io/dcptechnologies/spark:350-j17p3h3",
    cmds=[
    "sh",
    "-c",
    'java    -Dcom.amazonaws.sdk.disableCertChecking=true -Djavax.net.ssl.trustStore=/opt/finalcacert/cacerts -Djavax.net.ssl.trustStorePassword=changeit   -cp /opt/spark/conf:/opt/spark/jars/* -XX:+IgnoreUnrecognizedVMOptions --add-opens=java.base/java.lang=ALL-UNNAMED --add-opens=java.base/java.lang.invoke=ALL-UNNAMED --add-opens=java.base/java.lang.reflect=ALL-UNNAMED --add-opens=java.base/java.io=ALL-UNNAMED --add-opens=java.base/java.net=ALL-UNNAMED --add-opens=java.base/java.nio=ALL-UNNAMED --add-opens=java.base/java.util=ALL-UNNAMED --add-opens=java.base/java.util.concurrent=ALL-UNNAMED --add-opens=java.base/java.util.concurrent.atomic=ALL-UNNAMED --add-opens=java.base/sun.nio.ch=ALL-UNNAMED --add-opens=java.base/sun.nio.cs=ALL-UNNAMED --add-opens=java.base/sun.security.action=ALL-UNNAMED --add-opens=java.base/sun.util.calendar=ALL-UNNAMED --add-opens=java.security.jgss/sun.security.krb5=ALL-UNNAMED org.apache.spark.deploy.SparkSubmit --deploy-mode cluster --verbose --conf spark.master=k8s://https://192.168.12.134:8443 --conf spark.app.name=master-job01-rajcwd --conf spark.jars.ivy=/tmp --conf spark.kubernetes.file.upload.path=file:///opt/spark/work-dir --conf spark.kubernetes.submission.waitAppCompletion=true --conf spark.kubernetes.report.interval=1s --conf spark.kubernetes.namespace=demo --conf spark.kubernetes.container.image=docker.io/dcptechnologies/spark:350-j17p3h3 --conf spark.kubernetes.container.image.pullPolicy=IfNotPresent --conf spark.kubernetes.container.image.pullSecrets=dcpregistry --conf spark.kubernetes.authenticate.serviceAccountName=job01-sa --conf spark.kubernetes.driver.podTemplateFile=/opt/spark/template/driver.yaml --conf spark.kubernetes.executor.podTemplateFile=/opt/spark/template/executor.yaml --conf spark.hadoop.fs.s3a.bucket.sparkartifact.aws.credentials.provider=org.apache.hadoop.fs.s3a.SimpleAWSCredentialsProvider --conf spark.hadoop.fs.s3a.bucket.sparkartifact.impl=org.apache.hadoop.fs.s3a.S3AFileSystem --conf spark.hadoop.fs.s3a.bucket.sparkartifact.change.detection.version.require=false --conf spark.hadoop.fs.s3a.bucket.sparkartifact.access.key=admin --conf spark.hadoop.fs.s3a.bucket.sparkartifact.secret.key=DcpAdminPassword2016. --conf spark.hadoop.fs.s3a.bucket.sparkartifact.endpoint=https://masterstorage-minio.dcp.svc.cluster.local:9000 --conf spark.hadoop.fs.s3a.bucket.sparkartifact.path.style.access=true --conf spark.hadoop.fs.s3a.bucket.sparkartifact.signing-algorithm=S3SignerType --conf spark.hadoop.fs.s3a.bucket.sparkartifact.connection.ssl.enabled=true --conf spark.hadoop.fs.s3a.connection.timeout=1200000 --conf spark.hadoop.fs.s3a.connection.maximum=200 --conf spark.hadoop.fs.s3a.fast.upload=true --conf spark.hadoop.fs.s3a.readahead.range=256K --conf spark.hadoop.fs.s3a.input.fadvise=random --conf spark.hadoop.fs.s3a.impl=org.apache.hadoop.fs.s3a.S3AFileSystem --conf spark.kubernetes.driver.pod.name=master-job01-driver-rajcwd --conf spark.kubernetes.driver.label.master-cloud-provider=local --conf spark.kubernetes.driver.label.master-release=master-spark-application --conf spark.kubernetes.driver.label.managed-by=dcp --conf spark.kubernetes.driver.label.master-application-name=job01 --conf spark.kubernetes.driver.label.master-application-type=spark --conf spark.kubernetes.driver.label.master-workspace=default --conf spark.kubernetes.driver.annotation.master-cloud-provider=local --conf spark.driver.memoryOverheadFactor=0.1 --conf spark.kubernetes.authenticate.driver.serviceAccountName=job01-sa --conf spark.kubernetes.driver.request.cores=1 --conf spark.kubernetes.driver.limit.cores=2 --conf spark.driver.memory=1g --conf spark.driver.extraJavaOptions=" -Dcom.amazonaws.sdk.disableCertChecking=true -Djavax.net.ssl.trustStore=/opt/finalcacert/cacerts -Djavax.net.ssl.trustStorePassword=changeit " --conf spark.kubernetes.driver.volumes.emptyDir.data.mount.path=/opt/spark/work-dir --conf spark.kubernetes.driver.volumes.emptyDir.data.mount.readOnly=false --conf spark.kubernetes.driver.volumes.emptyDir.tmp.mount.path=/tmp --conf spark.kubernetes.driver.volumes.emptyDir.tmp.mount.readOnly=false --conf spark.kubernetes.executor.podNamePrefix=master-job01-executor-rajcwd --conf spark.kubernetes.executor.label.master-cloud-provider=local --conf spark.kubernetes.executor.label.master-release=master-spark-application --conf spark.kubernetes.executor.label.managed-by=dcp --conf spark.kubernetes.executor.label.master-application-name=job01 --conf spark.kubernetes.executor.label.master-application-type=spark --conf spark.kubernetes.executor.label.master-workspace=default --conf spark.kubernetes.executor.annotation.master-cloud-provider=local --conf spark.executor.memoryOverheadFactor=0.1 --conf spark.kubernetes.authenticate.executor.serviceAccountName=job01-sa --conf spark.executor.instances=1 --conf spark.kubernetes.executor.request.cores=1 --conf spark.kubernetes.executor.limit.cores=2 --conf spark.executor.memory=1g --conf spark.executor.extraJavaOptions=" -Dcom.amazonaws.sdk.disableCertChecking=true -Djavax.net.ssl.trustStore=/opt/finalcacert/cacerts -Djavax.net.ssl.trustStorePassword=changeit " --conf spark.kubernetes.executor.volumes.emptyDir.data.mount.path=/opt/spark/work-dir --conf spark.kubernetes.executor.volumes.emptyDir.data.mount.readOnly=false --conf spark.kubernetes.executor.volumes.emptyDir.tmp.mount.path=/tmp --conf spark.kubernetes.executor.volumes.emptyDir.tmp.mount.readOnly=false --conf spark.speculation=false --conf spark.network.timeout=2400 --class org.apache.spark.examples.SparkPi s3a://sparkartifact/sparkexamples/spark-examples_2.12-3.5.0.jar 500'
    ],
    name="master-job01-launcher-rajcwd",
    task_id="master-spark-task-job01-rajcwd",
    env_vars={
    "SPARK_WORKER_DIR": "/opt/spark/work-dir"
    },
    init_containers=[init_container_dndnode_3],
    volume_mounts=[vm_sparktemplate_job01_rajcwd, volume_mount_passwd_job01_rajcwd, volume_mount_tmpdir_job01_rajcwd, volume_mount_finalcacert_job01_rajcwd, volume_mount_cert_rajcwd],
    volumes=[v_sparktemplate_tmp_job01_rajcwd, volume_passwd_job01_rajcwd, volume_tmpdir_job01_rajcwd, volume_finalcacet_job01_rajcwd, volume_cert_job01_rajcwd],
    service_account_name='job01-sa',
    labels={
    "master-cloud-provider":"local",
    "master-release":"master-spark-application",
    "managed-by":"dcp",
    "master-application-name":"job01",
    "master-application-type":"spark",
    "master-workspace":"default"
    },
    security_context={
    "runAsNonRoot": True,
    "runAsUser": 7000,
    "allowPrivilegeEscalation": False,
    "seccompProfile":{
        "type": "RuntimeDefault"
    },
    "capabilities": {
        'drop': '["ALL"]'
    }
    },
    container_resources=compute_resources_job01_rajcwd,
    get_logs=True,
    dag=dag
    )
    dndnode_5 = KubernetesPodOperator(namespace='demo',
    image="docker.io/dcptechnologies/spark:350-j17p3h3",
    cmds=[
    "sh",
    "-c",
    'java    -Dcom.amazonaws.sdk.disableCertChecking=true -Djavax.net.ssl.trustStore=/opt/finalcacert/cacerts -Djavax.net.ssl.trustStorePassword=changeit   -cp /opt/spark/conf:/opt/spark/jars/* -XX:+IgnoreUnrecognizedVMOptions --add-opens=java.base/java.lang=ALL-UNNAMED --add-opens=java.base/java.lang.invoke=ALL-UNNAMED --add-opens=java.base/java.lang.reflect=ALL-UNNAMED --add-opens=java.base/java.io=ALL-UNNAMED --add-opens=java.base/java.net=ALL-UNNAMED --add-opens=java.base/java.nio=ALL-UNNAMED --add-opens=java.base/java.util=ALL-UNNAMED --add-opens=java.base/java.util.concurrent=ALL-UNNAMED --add-opens=java.base/java.util.concurrent.atomic=ALL-UNNAMED --add-opens=java.base/sun.nio.ch=ALL-UNNAMED --add-opens=java.base/sun.nio.cs=ALL-UNNAMED --add-opens=java.base/sun.security.action=ALL-UNNAMED --add-opens=java.base/sun.util.calendar=ALL-UNNAMED --add-opens=java.security.jgss/sun.security.krb5=ALL-UNNAMED org.apache.spark.deploy.SparkSubmit --deploy-mode cluster --verbose --conf spark.master=k8s://https://192.168.12.134:8443 --conf spark.app.name=master-pysparkenv-thbljv --conf spark.jars.ivy=/tmp --conf spark.kubernetes.file.upload.path=file:///opt/spark/work-dir --conf spark.kubernetes.submission.waitAppCompletion=true --conf spark.kubernetes.report.interval=1s --conf spark.kubernetes.namespace=demo --conf spark.kubernetes.container.image=docker.io/dcptechnologies/spark:350-j17p3h3 --conf spark.kubernetes.container.image.pullPolicy=IfNotPresent --conf spark.kubernetes.container.image.pullSecrets=dcpregistry --conf spark.kubernetes.authenticate.serviceAccountName=pysparkenv-sa --conf spark.kubernetes.driver.podTemplateFile=/opt/spark/template/driver.yaml --conf spark.kubernetes.executor.podTemplateFile=/opt/spark/template/executor.yaml --conf spark.kubernetes.driver.secretKeyRef.TRANSFORM_OUTPUT_FOLDER=pyspark:TRANSFORM_OUTPUT_FOLDER --conf spark.kubernetes.executor.secretKeyRef.TRANSFORM_OUTPUT_FOLDER=pyspark:TRANSFORM_OUTPUT_FOLDER --conf spark.kubernetes.driver.secretKeyRef.TRANSFORM_OUTPUT_FOLDER=pyspark:TRANSFORM_OUTPUT_FOLDER --conf spark.kubernetes.executor.secretKeyRef.TRANSFORM_OUTPUT_FOLDER=pyspark:TRANSFORM_OUTPUT_FOLDER --conf spark.hadoop.fs.s3a.bucket.sparkartifact.aws.credentials.provider=org.apache.hadoop.fs.s3a.SimpleAWSCredentialsProvider --conf spark.hadoop.fs.s3a.bucket.sparkartifact.impl=org.apache.hadoop.fs.s3a.S3AFileSystem --conf spark.hadoop.fs.s3a.bucket.sparkartifact.change.detection.version.require=false --conf spark.hadoop.fs.s3a.bucket.sparkartifact.access.key=admin --conf spark.hadoop.fs.s3a.bucket.sparkartifact.secret.key=DcpAdminPassword2016. --conf spark.hadoop.fs.s3a.bucket.sparkartifact.endpoint=https://masterstorage-minio.dcp.svc.cluster.local:9000 --conf spark.hadoop.fs.s3a.bucket.sparkartifact.path.style.access=true --conf spark.hadoop.fs.s3a.bucket.sparkartifact.signing-algorithm=S3SignerType --conf spark.hadoop.fs.s3a.bucket.sparkartifact.connection.ssl.enabled=true --conf spark.hadoop.fs.s3a.connection.timeout=1200000 --conf spark.hadoop.fs.s3a.connection.maximum=200 --conf spark.hadoop.fs.s3a.fast.upload=true --conf spark.hadoop.fs.s3a.readahead.range=256K --conf spark.hadoop.fs.s3a.input.fadvise=random --conf spark.hadoop.fs.s3a.impl=org.apache.hadoop.fs.s3a.S3AFileSystem --conf spark.kubernetes.driver.pod.name=master-pysparkenv-driver-thbljv --conf spark.kubernetes.driver.label.master-cloud-provider=local --conf spark.kubernetes.driver.label.master-release=master-spark-application --conf spark.kubernetes.driver.label.managed-by=dcp --conf spark.kubernetes.driver.label.master-application-name=pysparkenv --conf spark.kubernetes.driver.label.master-application-type=spark --conf spark.kubernetes.driver.label.master-workspace=default --conf spark.kubernetes.driver.annotation.master-cloud-provider=local --conf spark.driver.memoryOverheadFactor=0.1 --conf spark.kubernetes.authenticate.driver.serviceAccountName=pysparkenv-sa --conf spark.kubernetes.driver.request.cores=1 --conf spark.kubernetes.driver.limit.cores=2 --conf spark.driver.memory=1g --conf spark.driver.extraJavaOptions=" -Dcom.amazonaws.sdk.disableCertChecking=true -Djavax.net.ssl.trustStore=/opt/finalcacert/cacerts -Djavax.net.ssl.trustStorePassword=changeit " --conf spark.kubernetes.driver.volumes.emptyDir.data.mount.path=/opt/spark/work-dir --conf spark.kubernetes.driver.volumes.emptyDir.data.mount.readOnly=false --conf spark.kubernetes.driver.volumes.emptyDir.tmp.mount.path=/tmp --conf spark.kubernetes.driver.volumes.emptyDir.tmp.mount.readOnly=false --conf spark.kubernetes.executor.podNamePrefix=master-pysparkenv-executor-thbljv --conf spark.kubernetes.executor.label.master-cloud-provider=local --conf spark.kubernetes.executor.label.master-release=master-spark-application --conf spark.kubernetes.executor.label.managed-by=dcp --conf spark.kubernetes.executor.label.master-application-name=pysparkenv --conf spark.kubernetes.executor.label.master-application-type=spark --conf spark.kubernetes.executor.label.master-workspace=default --conf spark.kubernetes.executor.annotation.master-cloud-provider=local --conf spark.executor.memoryOverheadFactor=0.1 --conf spark.kubernetes.authenticate.executor.serviceAccountName=pysparkenv-sa --conf spark.executor.instances=1 --conf spark.kubernetes.executor.request.cores=1 --conf spark.kubernetes.executor.limit.cores=2 --conf spark.executor.memory=1g --conf spark.executor.extraJavaOptions=" -Dcom.amazonaws.sdk.disableCertChecking=true -Djavax.net.ssl.trustStore=/opt/finalcacert/cacerts -Djavax.net.ssl.trustStorePassword=changeit " --conf spark.kubernetes.executor.volumes.emptyDir.data.mount.path=/opt/spark/work-dir --conf spark.kubernetes.executor.volumes.emptyDir.data.mount.readOnly=false --conf spark.kubernetes.executor.volumes.emptyDir.tmp.mount.path=/tmp --conf spark.kubernetes.executor.volumes.emptyDir.tmp.mount.readOnly=false --conf spark.speculation=false --conf spark.network.timeout=2400 s3a://sparkartifact/pysparkenv/pyspark-parquet-duplicate-shuffle-env.py s3a://sparkartifact/input/iris.parq 1'
    ],
    name="master-pysparkenv-launcher-thbljv",
    task_id="master-spark-task-pysparkenv-thbljv",
    env_vars={
    "SPARK_WORKER_DIR": "/opt/spark/work-dir"
    },
    init_containers=[init_container_dndnode_5],
    volume_mounts=[vm_sparktemplate_pysparkenv_thbljv, volume_mount_passwd_pysparkenv_thbljv, volume_mount_tmpdir_pysparkenv_thbljv, volume_mount_finalcacert_pysparkenv_thbljv, volume_mount_cert_thbljv],
    volumes=[v_sparktemplate_tmp_pysparkenv_thbljv, volume_passwd_pysparkenv_thbljv, volume_tmpdir_pysparkenv_thbljv, volume_finalcacet_pysparkenv_thbljv, volume_cert_pysparkenv_thbljv],
    service_account_name='pysparkenv-sa',
    labels={
    "master-cloud-provider":"local",
    "master-release":"master-spark-application",
    "managed-by":"dcp",
    "master-application-name":"pysparkenv",
    "master-application-type":"spark",
    "master-workspace":"default"
    },
    security_context={
    "runAsNonRoot": True,
    "runAsUser": 7000,
    "allowPrivilegeEscalation": False,
    "seccompProfile":{
        "type": "RuntimeDefault"
    },
    "capabilities": {
        'drop': '["ALL"]'
    }
    },
    container_resources=compute_resources_pysparkenv_thbljv,
    get_logs=True,
    dag=dag
    )
# START TASK

# START EDGE
    dndnode_1.set_downstream(dndnode_3)
    dndnode_3.set_downstream(dndnode_5)
    dndnode_5.set_downstream(dndnode_2)
# END EDGE