import React, { Component } from 'react';
import { connect } from "react-redux";
import Highlighter from 'react-highlight-words';

import * as API from '../../../helpers/Params';
import { dcpRestApi } from '../../../helpers/DcpRestApi';

import {
    message, Space, Spin, Switch, Tooltip, Card, Select,
    Row, Col, Button, Form, Input, Tag, Table, Divider,
}
    from 'antd';
import { EditFilled, QuestionCircleFilled, ReloadOutlined, SaveOutlined, SearchOutlined, PlusOutlined } from '@ant-design/icons';

const { TextArea } = Input;
const { Option } = Select;

class DcpPolicyRules extends Component {
    formRule = React.createRef();
    constructor(props) {
        super(props);
        this.searchInput = React.createRef();

        this.resourceaRef = React.createRef();
        this.resourcebRef = React.createRef();
        this.resourcecRef = React.createRef();
        this.resourcedRef = React.createRef();

        this.state = {
            loading: false,
            idselectedrule: 0,
            enabled: true,
            messageform: 'loading',
            groups: [],
            rules: [],

            catalogs: [],
            selectedcatalog: '',
            selectedcatalogs: [],


            schemas: [],
            selectedschema: '',

            tables: [],
            selectedtable: '',

            columns: [],

            accesstypestrinouser: [
                {
                    value: 'imprsonate',
                    label: 'imprsonate',
                }
            ],
            accesstypessystemproperty: [
                {
                    value: 'alter',
                    label: 'alter',
                }
            ],
            accesstypesfunction: [
                {
                    value: 'grant',
                    label: 'grant',
                },
                {
                    value: 'execute',
                    label: 'execute',
                }
            ],
            accesstypessessionproperty: [
                {
                    value: 'alter',
                    label: 'alter',
                }
            ],
            accesstypescatalogs: [
                {
                    value: 'select',
                    label: 'select',
                },
                {
                    value: 'insert',
                    label: 'insert',
                },
                {
                    value: 'create',
                    label: 'create',
                },
                {
                    value: 'drop',
                    label: 'drop',
                },
                {
                    value: 'delete',
                    label: 'delete',
                },
                {
                    value: 'use',
                    label: 'use',
                },
                {
                    value: 'alter',
                    label: 'alter',
                },
                {
                    value: 'grant',
                    label: 'grant',
                },
                {
                    value: 'revoke',
                    label: 'revoke',
                },
                {
                    value: 'show',
                    label: 'show',
                },
                {
                    value: 'impersonate',
                    label: 'impersonate',
                },
                {
                    value: 'all',
                    label: 'all',
                },
                {
                    value: 'execute',
                    label: 'execute',
                },
            ],
            accesstypesprocedure: [
                {
                    value: 'grant',
                    label: 'grant',
                },
                {
                    value: 'execute',
                    label: 'execute',
                }
            ],
            accesstypes: [],

            resourceaname: '',
            resourcesavalues: [],
            resourcesalabels: [
                "catalog",
                "trinouser",
                "systemproperty",
                "function",
            ],
            displayblevel: 'none',
            selectedtypealevel: 'catalog',


            resourcebname: '',
            schemasoptions: {},
            resourcesbvalues: [],
            resourcesblabels: [
                "schema",
                "sessionproperty",
                "none",
            ],
            displayclevel: 'none',
            selectedtypeblevel: 'schema',


            resourcecname: '',
            resourcescvalues: [],
            resourcesclabels: [
                "table",
                "procedure",
                "none",
            ],
            displaydlevel: 'none',
            selectedtypeclevel: 'table',


            resourcedname: '',
            resourcesdvalues: [],
            resourcesdlabels: [
                "column",
                "none",
            ],
            selectedtypedlevel: 'column',
        }

    }
    componentDidMount() {
        this.loadGroups();
    };
    shouldComponentUpdate(nextProps, nextState) {
        return true;
    };
    handleSearch = (selectedKeys, confirm, dataIndex) => {
        confirm();
        this.setState({
            searchText: selectedKeys[0],
            searchedColumn: dataIndex
        })
    };
    handleReset = (clearFilters) => {
        clearFilters();
        //setSearchText('');
        this.setState({ searchText: '' })
    };
    getColumnSearchProps = (dataIndex) => ({
        filterDropdown: ({ setSelectedKeys, selectedKeys, confirm, clearFilters, close }) => (
            <div
                style={{
                    padding: 8,
                }}
                onKeyDown={(e) => e.stopPropagation()}
            >
                <Input
                    ref={this.searchInput}
                    placeholder={`Search ${dataIndex}`}
                    value={selectedKeys[0]}
                    onChange={(e) => setSelectedKeys(e.target.value ? [e.target.value] : [])}
                    onPressEnter={() => this.handleSearch(selectedKeys, confirm, dataIndex)}
                    style={{
                        marginBottom: 8,
                        display: 'block',
                    }}
                />
                <Space>
                    <Button
                        type="primary"
                        onClick={() => this.handleSearch(selectedKeys, confirm, dataIndex)}
                        icon={<SearchOutlined />}
                        size="small"
                        style={{
                            width: 90,
                        }}
                    >
                        Search
                    </Button>
                    <Button
                        onClick={() => clearFilters && this.handleReset(clearFilters)}
                        size="small"
                        style={{
                            width: 90,
                        }}
                    >
                        Reset
                    </Button>
                    <Button
                        type="link"
                        size="small"
                        onClick={() => {
                            confirm({
                                closeDropdown: false,
                            });
                            //setSearchText(selectedKeys[0]);
                            this.setState({
                                setSearchText: selectedKeys[0],
                                searchedColumn: dataIndex
                            })
                            //setSearchedColumn(dataIndex);
                        }}
                    >
                        Filter
                    </Button>
                    <Button
                        type="link"
                        size="small"
                        onClick={() => {
                            close();
                        }}
                    >
                        close
                    </Button>
                </Space>
            </div>
        ),
        filterIcon: (filtered) => (
            <SearchOutlined
                style={{
                    color: filtered ? '#1890ff' : undefined,
                }}
            />
        ),
        onFilter: (value, record) =>
            record[dataIndex].toString().toLowerCase().includes(value.toLowerCase()),
        onFilterDropdownOpenChange: (visible) => {
            if (visible) {
                setTimeout(() => this.searchInput.current?.select(), 100);
            }
        },
        render: (text) =>
            this.state.searchedColumn === dataIndex ? (
                <Highlighter
                    highlightStyle={{
                        backgroundColor: '#ffc069',
                        padding: 0,
                    }}
                    searchWords={[this.state.searchText]}
                    autoEscape
                    textToHighlight={text ? text.toString() : ''}
                />
            ) : (
                text
            ),
    });

    loadRules = () => {
        this.setState({ loading: true, messageform: 'Loading rules.....' }, () => {
            dcpRestApi.restGetTemplate(this.props.authReducer.user, API.DCP_SQL_POLICY_LIST_RULE)
                .then((response) => {
                    this.setState({
                        loading: false,
                        rules: response.data
                    })
                })
                .catch(error => {
                    if (typeof error.response.data === 'string') {
                        message.error("Error: " + error.response.data)
                    } else {
                        message.error("Error: " + error.response.data.error)
                    }
                    this.setState({
                        loading: false
                    });
                });
        });
    };
    selectRule = (record) => {
        this.setState({ loading: true, messageform: 'Loading rules.....' }, () => {
            dcpRestApi.restGetTemplate(this.props.authReducer.user, API.DCP_SQL_POLICY_GET_RULE + '/' + record.name)
                .then((response) => {
                    console.log(response.data)
                    this.setState({
                        idselectedrule: response.data.key,
                        enabled: response.data.enabled,
                        loading: false,

                        displayblevel: response.data.resourcebtype === 'schema' ? 'block' : 'none',
                        displaclevel: response.data.resourdectype === 'table' ? 'block' : 'none',

                        selectedcatalog: response.data.resourceavalues,
                        selectedschema: response.data.resourcebvalues,
                        selectedtable: response.data.resourcecvalues,
                    }, () => {
                        this.formRule.current.setFieldsValue({
                            name: response.data.name,
                            description: response.data.description,

                            resourceatype: response.data.resourceatype,
                            resourceavalues: response.data.resourceavalues,

                            resourcebtype: response.data.resourcebtype,
                            resourcebvalues: response.data.resourcebvalues,

                            resourcectype: response.data.resourcectype,
                            resourcecvalues: response.data.resourcecvalues,

                            resourcedtype: response.data.resourcedtype,
                            resourcedvalues: response.data.resourcedvalues,

                            groups: response.data.groups,
                            roles: response.data.roles,
                        });
                        if (response.data.resourceatype === 'catalog') {
                            this.handleChangeResourceTypeA(response.data.resourceatype)
                            this.handleChangeResourceTypeB(response.data.resourcebtype)
                            this.handleChangeResourceTypeC(response.data.resourcectype)
                            this.handleChangeResourceTypeD(response.data.resourcedtype)
                        }
                    })
                })
                .catch(error => {
                    if (typeof error.response.data === 'string') {
                        message.error("Error: " + error.response.data)
                    } else {
                        message.error("Error: " + error.response.data.error)
                    }
                    this.setState({
                        loading: false
                    });
                });
        });
    };
    handleResetForm = () => {
        this.setState({
            idselectedrule: 0,
            enabled: true,

            displayblevel: 'none',
            displayclevel: 'none',
            displaydlevel: 'none',
        }, () => {
            this.formRule.current.setFieldsValue({
                name: '',
                description: '',
                resourceatype: 'none',
                resourceavalues: '',

                resourcebtype: 'none',
                resourcebvalues: '',

                resourcectype: 'none',
                resourcecvalues: '',

                resourcedtype: 'none',
                resourcedvalues: [],

                groups: [],
                roles: [],
            })
        })
    };
    handleSave = (record) => {
        const input = {
            ...record,
            key: this.state.idselectedrule,
            enabled: this.state.enabled,
        }
        console.log(input)
        this.setState({ loading: true, messageform: 'Saving rule.....' }, () => {
            dcpRestApi.restPostTemplate(this.props.authReducer.user, API.DCP_SQL_POLICY_ADD_RULE, input)
                .then((response) => {
                    message.success(response.data)
                    this.setState({
                        loading: false
                    }, () => {
                        this.loadRules();
                        //this.handleReset();
                    });
                })
                .catch(error => {
                    if (typeof error.response.data === 'string') {
                        message.error("Error: " + error.response.data)
                    } else {
                        message.error("Error: " + error.response.data.error)
                    }
                    this.setState({
                        loading: false
                    });
                });
        });
    };
    handleFailed = errorInfo => {
        let errmessage = "";
        let i = 0;
        while (i < errorInfo.errorFields.length) {
            errmessage += "[" + errorInfo.errorFields[i].name[0] + "]=[" + errorInfo.errorFields[i].errors[0] + "]"
            i++;
        }
        message.error('Error: ' + errmessage);
    };

    //load Groups
    loadGroups = () => {
        this.setState({ loading: true, messageform: 'Loading groups.....' }, () => {
            dcpRestApi.restGetTemplate(this.props.authReducer.user, API.DCP_SQL_POLICY_LIST_GROUP)
                .then((response) => {
                    this.setState({
                        loading: false,
                        groups: response.data
                    })
                })
                .catch(error => {
                    if (typeof error.response.data === 'string') {
                        message.error("Error: " + error.response.data)
                    } else {
                        message.error("Error: " + error.response.data.error)
                    }
                    this.setState({
                        loading: false
                    });
                });
        });
    }
    //load catalogs
    loadCatalogs = () => {
        this.setState({ resourcesavalues: [], loading: true, messageform: 'Loading catalogs.....' }, () => {
            dcpRestApi.restGetTemplate(this.props.authReducer.user, API.DCP_SQL_POLCIY_LIST_CATALOGS)
                .then((response) => {
                    this.setState({
                        loading: false,
                        resourcesavalues: response.data != undefined ? response.data.data : [],
                    })
                })
                .catch(error => {
                    if (typeof error.response.data === 'string') {
                        message.error("Error: " + error.response.data)
                    } else {
                        message.error("Error: " + error.response.data.error)
                    }
                    this.setState({
                        loading: false
                    });
                });
        });
    }

    //loadschemas
    loadSchemas = (catalog) => {
        this.setState({ selectedcatalog: catalog, resourcesbvalues: [], loading: true, messageform: 'Loading schemas.....' }, () => {
            dcpRestApi.restGetTemplate(this.props.authReducer.user, API.DCP_SQL_POLCIY_LIST_SCHEMAS + '/' + catalog)
                .then((response) => {
                    this.setState({
                        loading: false,
                        resourcesbvalues: response.data != undefined ? response.data.data : [],
                    })
                })
                .catch(error => {
                    if (typeof error.response.data === 'string') {
                        message.error("Error: " + error.response.data)
                    } else {
                        message.error("Error: " + error.response.data.error)
                    }
                    this.setState({
                        loading: false
                    });
                });
        });
    }
    loadSchemasByCatalogs = (catalogs) => {
        this.setState({ resourcesbvalues: [], loading: true, messageform: 'Loading schemas.....' }, () => {
            dcpRestApi.restPostTemplate(this.props.authReducer.user, API.DCP_SQL_POLCIY_LIST_SCHEMAS_BIS, catalogs)
                .then((response) => {
                    console.log(response.data)
                    this.setState({
                        loading: false,
                        resourcesbvalues: response.data != undefined ? response.data.data : [],
                    })
                })
                .catch(error => {
                    if (typeof error.response.data === 'string') {
                        message.error("Error: " + error.response.data)
                    } else {
                        message.error("Error: " + error.response.data.error)
                    }
                    this.setState({
                        loading: false
                    });
                });
        });
    }

    //load tables
    loadTables = (schema) => {
        this.setState({ selectedschema: schema, tables: [], loading: true, messageform: 'Loading tables.....' }, () => {
            dcpRestApi.restGetTemplate(this.props.authReducer.user, API.DCP_SQL_POLCIY_LIST_TABLES + '/' + this.state.selectedcatalog + '/' + schema)
                .then((response) => {
                    this.setState({
                        loading: false,
                        resourcescvalues: response.data != undefined ? response.data.data : [],
                    })
                })
                .catch(error => {
                    if (typeof error.response.data === 'string') {
                        message.error("Error: " + error.response.data)
                    } else {
                        message.error("Error: " + error.response.data.error)
                    }
                    this.setState({
                        loading: false
                    });
                });
        });
    }

    //load columns
    loadColumns = (table) => {
        this.setState({ selectedtable: table, columns: [], loading: true, messageform: 'Loading columns.....' }, () => {
            dcpRestApi.restGetTemplate(this.props.authReducer.user, API.DCP_SQL_POLCIY_LIST_COLUMNS + '/' + this.state.selectedcatalog + '/' + this.state.selectedschema + '/' + table)
                .then((response) => {
                    this.setState({
                        loading: false,
                        resourcesdvalues: response.data != undefined ? response.data.data : [],
                    })
                })
                .catch(error => {
                    if (typeof error.response.data === 'string') {
                        message.error("Error: " + error.response.data)
                    } else {
                        message.error("Error: " + error.response.data.error)
                    }
                    this.setState({
                        loading: false
                    });
                });
        });
    };


    //CATALOGS
    onResourceAChange = (event) => {
        this.setState({
            resourceaname: event.target.value
        })
    };
    addResourceA = (e) => {
        e.preventDefault();
        let resourcesavalues = this.state.resourcesavalues;
        resourcesavalues.push({ name: this.state.resourceaname })
        this.setState({
            resourcesavalues: resourcesavalues,
            resourceaname: ''
        })
    };
    handleChangeResourceTypeA = (label) => {
        if (label === '' || label == undefined) {
            label = 'none'
        }
        this.setState({ selectedtypeblevel: label }, () => {
            if (label === 'none') {
                this.setState({
                    resourcesavalues: [],
                    resourcesbvalues: [],
                    resourcescvalues: [],
                    resourcesdvalues: [],
                    displayblevel: 'none',
                    displayclevel: 'none',
                    displaydlevel: 'none',
                }, () => {
                    this.formRule.current.setFieldsValue({
                        resourceatype: 'none',
                        resourceavalues: '',

                        resourcebtype: 'none',
                        resourcebvalues: '',

                        resourcectype: 'none',
                        resourcecvalues: '',

                        resourcedtype: 'none',
                        resourcedvalues: [],
                    })
                })
            }
            if (label === 'catalog') {
                this.setState({ displayblevel: 'block', selectedtypeblevel: 'none', accesstypes: this.state.accesstypescatalogs }, () => {
                    this.loadCatalogs();
                    this.formRule.current.setFieldsValue({
                        //resourcebtype: 'none',
                    })
                })
            }
            if (label === 'trinouser' || label === 'systemproperty' || label === 'function') {
                this.setState({
                    resourcesavalues: [],
                    resourcesbvalues: [],
                    resourcescvalues: [],
                    resourcesdvalues: [],
                    displayblevel: 'none',
                    displayclevel: 'none',
                    displaydlevel: 'none',
                }, () => {
                    this.formRule.current.setFieldsValue({
                        resourceavalues: '',

                        resourcebtype: 'none',
                        resourcebvalues: '',

                        resourcectype: 'none',
                        resourcecvalues: '',

                        resourcedtype: 'none',
                        resourcedvalues: [],
                    })
                })
            }
            if (label === 'trinouser') {
                this.setState({ accesstypes: this.state.accesstypestrinouser })
            }
            if (label === 'systemproperty') {
                this.setState({ accesstypes: this.state.accesstypessystemproperty })
            }
            if (label === 'function') {
                this.setState({ accesstypes: this.state.accesstypesfunction })
            }
        })
    }
    handleChangeResourceValueA = (catalogs) => {
        if (this.state.selectedtypealevel === 'catalog') {
            this.setState({ selectedcatalogs: catalogs }, () => {
                /* if (this.state.selectedtypeblevel === 'schema') {
                    const input = {data: value}
                    this.loadSchemasByCatalogs(input)
                } */
            })
        }
    }
    /* handleChangeResourceValueA = (value) => {
        if (this.state.selectedtypealevel === 'catalog') {
            this.setState({ selectedcatalog: value }, () => {
                if (this.state.selectedtypeblevel === 'schema') {
                    const input = {
                        data: value
                    }
                    console.log(input)
                    this.loadSchemasByCatalogs(input)
                }
            })
        }
    } */

    //SCHEMAS
    onResourceBChange = (event) => {
        this.setState({
            resourcebname: event.target.value,
        })
    };
    addResourceB = (e) => {
        e.preventDefault();
        let resourcesbvalues = this.state.resourcesbvalues;
        resourcesbvalues.push({ name: this.state.resourcebname })
        this.setState({
            resourcesbvalues: resourcesbvalues,
            resourcebname: ''
        })
    };
    handleChangeResourceTypeB = (label) => {
        if (label === '' || label == undefined) {
            label = 'none'
        }
        this.setState({ selectedtypeblevel: label }, () => {
            if (label === 'none') {
                this.setState({
                    resourcesbvalues: [],
                    resourcescvalues: [],
                    resourcesdvalues: [],
                    displayclevel: 'none',
                    displaydlevel: 'none',
                }, () => {
                    this.formRule.current.setFieldsValue({
                        resourcebtype: 'none',
                        resourcebvalues: '',

                        resourcectype: 'none',
                        resourcecvalues: '',

                        resourcedtype: 'none',
                        resourcedvalues: [],
                    })
                })
            }
            if (label === 'schema' && this.state.selectedcatalog != '') {
                this.setState({ displayclevel: 'block', selectedtypeclevel: 'none' }, () => {
                    //this.loadSchemas(this.state.selectedcatalog);                    
                    this.loadSchemasByCatalogs({data: this.state.selectedcatalogs})
                    //this.formRule.current.setFieldsValue({
                        //resourcectype: 'none',
                    //})
                })
            }
            if (label === 'sessionproperty') {
                this.setState({
                    resourcesbvalues: [],
                    resourcescvalues: [],
                    resourcesdvalues: [],
                    displayclevel: 'none',
                    displaydlevel: 'none',
                    accesstypes: this.state.accesstypessessionproperty,
                }, () => {
                    this.formRule.current.setFieldsValue({
                        resourcectype: 'none',
                        resourcecvalues: '',

                        resourcedtype: 'none',
                        resourcedvalues: [],
                    })
                })
            }
        })
    };
    handleChangeResourceValueB = (value) => {
        if (this.state.selectedtypeblevel === 'schema') {
            this.setState({ selectedschema: value }, () => {
                if (this.state.selectedtypeclevel === 'table') {
                    this.setState({ displayclevel: 'block', selectedtypedlevel: 'none' }, () => {
                        this.loadTables(value);
                        this.formRule.current.setFieldsValue({
                            //resourcedtype: 'none',
                        })
                    })
                }
            })
        }
    };

    //TABLES
    onResourceCChange = (event) => {
        this.setState({
            resourcecname: event.target.value,
        })
    };
    addResourceC = (e) => {
        e.preventDefault();
        let resourcescvalues = this.state.resourcescvalues;
        resourcescvalues.push({ name: this.state.resourcecname })
        this.setState({
            resourcescvalues: resourcescvalues,
            resourcecname: ''
        })
    };
    handleChangeResourceTypeC = (label) => {
        if (label === '' || label == undefined) {
            label = 'none'
        }
        this.setState({ selectedtypeclevel: label }, () => {
            if (label === 'none') {
                this.setState({
                    resourcescvalues: [],
                    resourcesdvalues: [],
                    displaydlevel: 'none',
                }, () => {
                    this.formRule.current.setFieldsValue({
                        resourcectype: 'none',
                        resourcecvalues: '',

                        resourcedtype: 'none',
                        resourcedvalues: [],
                    })
                })
            }
            if (label === 'table' && this.state.selectedschema != '') {
                this.setState({ displaydlevel: 'block', selectedtypedlevel: 'none' }, () => {
                    this.loadTables(this.state.selectedschema);
                    this.formRule.current.setFieldsValue({
                        //resourcedtype: 'none',
                    })
                })
            }
            if (label === 'procedure') {
                this.setState({
                    resourcescvalues: [],
                    resourcesdvalues: [],
                    displaydlevel: 'none',
                    accesstypes: this.state.accesstypesprocedure
                }, () => {
                    this.formRule.current.setFieldsValue({
                        resourcedtype: 'none',
                        resourcedvalues: [],
                    })
                })
            }
        })
    };
    handleChangeResourceValueC = (value) => {
        if (this.state.selectedtypeclevel === 'table') {
            this.setState({ selectedtable: value }, () => {
                if (this.state.selectedtypedlevel === 'column') {
                    this.loadColumns(value)
                }
            })
        }
    };


    //COLUMNS
    onResourceDChange = (event) => {
        this.setState({
            resourcedname: event.target.value,
        })
    };
    addResourceD = (e) => {
        e.preventDefault();
        let resourcesdvalues = this.state.resourcesdvalues;
        resourcesdvalues.push({ name: this.state.resourcedname })
        this.setState({
            resourcesdvalues: resourcesdvalues,
            resourcedname: ''
        })
    };
    handleChangeResourceTypeD = (label) => {
        if (label === '' || label == undefined) {
            label = 'none'
        }
        this.setState({ selectedtypedlevel: label }, () => {
            if (label === 'none') {
                this.setState({
                    resourcesdvalues: [],
                }, () => {
                    this.formRule.current.setFieldsValue({
                        resourcedtype: 'none',
                        resourcedvalues: [],
                    })
                })
            }
            if (label === 'column' && this.state.selectedtable != '') {
                this.setState({ displayelevel: 'block', selectedtypeelevel: 'none' }, () => {
                    this.loadColumns(this.state.selectedtable);
                    /* this.formRule.current.setFieldsValue({
                        resourceetype: 'none',
                    }) */
                })
            }
        })
    };

    render() {
        const props = {
            bordered: true,
            title: () => {
                return <Row>
                    <Col span={18}>
                        <b>Rules:</b>
                    </Col>
                    <Col span={6}>
                        <div style={{ textAlign: 'right' }}><Tooltip title="Reload Rules.">
                            <Button type="primary" onClick={this.loadRules} icon={<ReloadOutlined />} />
                        </Tooltip>
                        </div>
                    </Col>
                </Row>
            },
            size: 'small',
            showHeader: true,
            scroll: undefined,
            hasData: true,
            tableLayout: undefined,
            top: 'none',
            bottom: 'bottomRight'
        };
        const columns = [
            {
                title: '',
                dataIndex: 'name',
                key: 'name',
                //width: 10,
                render: (text, record) => (
                    <Space>
                        <Tooltip placement='topLeft' title="Edit">
                            <EditFilled style={{ fontSize: '18px', color: "#55acee" }} onClick={() => this.selectRule(record)} />
                        </Tooltip>
                    </Space>
                ),
            },
            {
                title: 'Name',
                dataIndex: 'name',
                key: 'name',
                ...this.getColumnSearchProps('name'),
                render: (text, record) => (
                    <>
                        <Tooltip placement='topLeft' title={record.description}>
                            <Tag size="large" color="#55acee">
                                <span style={{ fontSize: '14px' }}>{record.name}</span>
                            </Tag>
                        </Tooltip>
                    </>
                ),

            },
            {
                title: 'Type',
                dataIndex: 'resourcetype',
                key: 'resourcetype',
                ...this.getColumnSearchProps('resourcetype'),
            },
            {
                title: 'Enabled',
                key: 'enabled',
                dataIndex: 'v',
                render: (text, record) => {
                    if (record.enabled) {
                        return (
                            <Tag color='green' key={record.key}>
                                ENABLED
                            </Tag>
                        );
                    } else {
                        return (
                            <Tag color='volcano' key={record.key}>
                                DISABLED
                            </Tag>
                        );
                    }
                }
            },
        ];
        const handleChange = (a, b) => {
            //console.log(`selected ${value}`);
            console.log(a)
            console.log(b)
        };
        return (
            <>
                <Spin size="large" spinning={this.state.loading} tip={this.state.messageform}>
                    <Row gutter={[10, 0]}>
                        <Col span={10}>
                            <Table
                                {...props}
                                columns={columns}
                                dataSource={this.state.rules != undefined ? this.state.rules : []}
                            />
                        </Col>
                        <Col span={14}>
                            <Card bodyStyle={{ backgroundColor: 'rgb(248,248,248)', border: 10 }}>
                                <Row gutter={[10, 10]}>
                                    <Col span={24}>
                                        <Form
                                            size='default'
                                            ref={this.formRule}
                                            layout="horizontal"
                                            labelCol={{ span: 5 }}
                                            labelAlign="left"
                                            wrapperCol={{ span: 14 }}
                                            onFinish={this.handleSave}
                                            onFinishFailed={this.handleFailed}
                                            initialValues={{
                                                ['name']: '',
                                                ['description']: '',
                                                ['resourceatype']: 'none',
                                                ['resourcebtype']: 'none',
                                                ['resourcectype']: 'none',
                                                ['resourcedtype']: 'none',
                                            }}>
                                            <Row>
                                                <Col span={24}>
                                                    <Form.Item name="test" label="test">
                                                        <Select
                                                            defaultValue="lucy"
                                                            style={{
                                                                width: 200,
                                                            }}
                                                            onChange={handleChange}
                                                            options={[
                                                                {
                                                                    label: 'Manager',
                                                                    options: [
                                                                        {
                                                                            label: 'Jack',
                                                                            value: 'jack',
                                                                        },
                                                                        {
                                                                            label: 'Lucy',
                                                                            value: 'lucy',
                                                                        },
                                                                    ],
                                                                },
                                                                {
                                                                    label: 'Engineer',
                                                                    options: [
                                                                        {
                                                                            label: 'yiminghe',
                                                                            value: 'Yiminghe',
                                                                        },
                                                                    ],
                                                                },
                                                            ]}
                                                        />
                                                    </Form.Item>
                                                    <Form.Item name="enabled"
                                                        label={
                                                            <span>
                                                                <Space>
                                                                    <b>Enable</b>
                                                                    <Tooltip placement='topLeft' title="Enable/Disable Rule.">
                                                                        <QuestionCircleFilled style={{ fontSize: '18px', color: 'lightblue' }} />
                                                                    </Tooltip>
                                                                </Space>
                                                            </span>
                                                        }
                                                    >
                                                        <Switch checked={this.state.enabled} onClick={(enabled) => this.setState({ enabled: enabled })} />
                                                    </Form.Item>
                                                    <Form.Item name="name"
                                                        label={
                                                            <span>
                                                                <Space>
                                                                    Name
                                                                    <Tooltip placement='topLeft' title="Rule Name.">
                                                                        <QuestionCircleFilled style={{ fontSize: '18px', color: 'lightblue' }} />
                                                                    </Tooltip>
                                                                </Space>
                                                            </span>
                                                        } rules={[{ required: true, message: 'name is required' }]} className="align-left">
                                                        <Input placeholder='Name' showCount />
                                                    </Form.Item>
                                                    <Form.Item
                                                        name="description"
                                                        label={
                                                            <span>
                                                                <Space>
                                                                    Description
                                                                    <Tooltip placement='topLeft' title="Description (max: 400 char).">
                                                                        <QuestionCircleFilled style={{ fontSize: '18px', color: 'lightblue' }} />
                                                                    </Tooltip>
                                                                </Space>
                                                            </span>
                                                        }>
                                                        <TextArea
                                                            placeholder='Description'
                                                            style={{ fontSize: '14px' }}
                                                            rows='2' cols='20'
                                                            maxLength={400}
                                                            showCount
                                                        />
                                                    </Form.Item>
                                                    <Divider />
                                                    <Row>
                                                        <Col span={6}>
                                                            <Form.Item
                                                                name="resourceatype"
                                                                label=""
                                                                rules={[{ required: true, message: 'Resource is required' }]}>
                                                                <Select
                                                                    showSearch
                                                                    showArrow
                                                                    allowClear
                                                                    filterOption={(input, option) =>
                                                                        (option?.label ?? '').toLowerCase().includes(input.toLowerCase())
                                                                    }
                                                                    onChange={this.handleChangeResourceTypeA}
                                                                    options={this.state.resourcesalabels.map((obj) => ({
                                                                        label: obj,
                                                                        value: obj,
                                                                    }))}
                                                                />
                                                            </Form.Item>
                                                        </Col>
                                                        <Col span={18}>
                                                            <Form.Item
                                                                name="resourceavalues"
                                                                label=""
                                                                rules={[{ required: true, message: 'Resource is required' }]}>
                                                                <Select
                                                                    mode='multiple'
                                                                    showSearch
                                                                    showArrow
                                                                    allowClear
                                                                    filterOption={(input, option) =>
                                                                        (option?.label ?? '').toLowerCase().includes(input.toLowerCase())
                                                                    }
                                                                    placeholder="Select Resource"
                                                                    onChange={this.handleChangeResourceValueA}
                                                                    dropdownRender={(menu) => (
                                                                        <>
                                                                            {menu}
                                                                            <Divider style={{ margin: '8px 0', }} />
                                                                            <Space style={{ padding: '0 8px 4px', }}>
                                                                                <Row>
                                                                                    <Col span={22}>
                                                                                        <Input
                                                                                            placeholder="Please enter Resource Name"
                                                                                            ref={this.resourceaRef}
                                                                                            value={this.state.resourceaname}
                                                                                            onChange={this.onResourceAChange}
                                                                                        />
                                                                                    </Col>
                                                                                    <Col span={2}>
                                                                                        <Button type="text" icon={<PlusOutlined />} onClick={this.addResourceA}>
                                                                                            Add
                                                                                        </Button>
                                                                                    </Col>
                                                                                </Row>


                                                                            </Space>
                                                                        </>
                                                                    )}
                                                                    options={(this.state.resourcesavalues || []).map((d) => ({
                                                                        value: d.name,
                                                                        label: d.name,
                                                                    }))}
                                                                /* disabled={this.state.displayblevel !== 'block'} */
                                                                />
                                                            </Form.Item>
                                                        </Col>
                                                    </Row>
                                                    <div style={{ display: this.state.displayblevel }} >
                                                        <Row>
                                                            <Col span={6}>
                                                                <Form.Item
                                                                    name="resourcebtype"
                                                                    label=""
                                                                    rules={[{ required: this.state.displayblevel === 'block', message: 'Resource is required' }]}>
                                                                    <Select
                                                                        showSearch
                                                                        showArrow
                                                                        allowClear
                                                                        filterOption={(input, option) =>
                                                                            (option?.label ?? '').toLowerCase().includes(input.toLowerCase())
                                                                        }
                                                                        onChange={this.handleChangeResourceTypeB}
                                                                        options={this.state.resourcesblabels.map((obj) => ({
                                                                            label: obj,
                                                                            value: obj,
                                                                        }))}
                                                                    />
                                                                </Form.Item>
                                                            </Col>
                                                            <Col span={18}>
                                                                <Form.Item
                                                                    name="resourcebvalues"
                                                                    label=""
                                                                    rules={[{ required: this.state.displayblevel === 'block' && this.state.selectedtypeblevel != 'none', message: 'Resource is required' }]}>
                                                                    <Select
                                                                        showSearch
                                                                        showArrow
                                                                        allowClear
                                                                        filterOption={(input, option) =>
                                                                            (option?.label ?? '').toLowerCase().includes(input.toLowerCase())
                                                                        }
                                                                        placeholder="Select Resource"
                                                                        onChange={this.handleChangeResourceValueB}
                                                                        dropdownRender={(menu) => (
                                                                            <>
                                                                                {menu}
                                                                                <Divider style={{ margin: '8px 0', }} />
                                                                                <Space style={{ padding: '0 8px 4px', }}>
                                                                                    <Row>
                                                                                        <Col span={22}>
                                                                                            <Input
                                                                                                placeholder="Please enter Resource Name"
                                                                                                ref={this.resourcebRef}
                                                                                                value={this.state.resourcebname}
                                                                                                onChange={this.onResourceBChange}
                                                                                            />
                                                                                        </Col>
                                                                                        <Col span={2}>
                                                                                            <Button type="text" icon={<PlusOutlined />} onClick={this.addResourceB}>
                                                                                                Add
                                                                                            </Button>
                                                                                        </Col>
                                                                                    </Row>
                                                                                </Space>
                                                                            </>
                                                                        )}
                                                                        options={(this.state.resourcesbvalues || []).map((d) => ({
                                                                            value: d.name,
                                                                            label: d.name,
                                                                        }))}
                                                                    />
                                                                </Form.Item>
                                                            </Col>
                                                        </Row>

                                                        <div style={{ display: this.state.displayclevel }} >
                                                            <Row>
                                                                <Col span={6}>
                                                                    <Form.Item
                                                                        name="resourcectype"
                                                                        label=""
                                                                        rules={[{ required: this.state.displayclevel === 'block', message: 'Resource is required' }]}>
                                                                        <Select
                                                                            showSearch
                                                                            showArrow
                                                                            allowClear
                                                                            filterOption={(input, option) =>
                                                                                (option?.label ?? '').toLowerCase().includes(input.toLowerCase())
                                                                            }
                                                                            onChange={this.handleChangeResourceTypeC}
                                                                            options={this.state.resourcesclabels.map((obj) => ({
                                                                                label: obj,
                                                                                value: obj,
                                                                            }))}
                                                                        />
                                                                    </Form.Item>
                                                                </Col>
                                                                <Col span={18}>
                                                                    <Form.Item
                                                                        name="resourcecvalues"
                                                                        label=""
                                                                        rules={[{ required: this.state.displayclevel === 'block' && this.state.selectedtypeclevel != 'none', message: 'Resource is required' }]}>
                                                                        <Select
                                                                            showSearch
                                                                            showArrow
                                                                            allowClear
                                                                            filterOption={(input, option) =>
                                                                                (option?.label ?? '').toLowerCase().includes(input.toLowerCase())
                                                                            }
                                                                            placeholder="Select Resource"
                                                                            onChange={this.handleChangeResourceValueC}
                                                                            dropdownRender={(menu) => (
                                                                                <>
                                                                                    {menu}
                                                                                    <Divider style={{ margin: '8px 0', }} />
                                                                                    <Space style={{ padding: '0 8px 4px', }}>
                                                                                        <Row>
                                                                                            <Col span={22}>
                                                                                                <Input
                                                                                                    placeholder="Please enter Resource Name"
                                                                                                    ref={this.resourcecRef}
                                                                                                    value={this.state.resourcecname}
                                                                                                    onChange={this.onResourceCChange}
                                                                                                />
                                                                                            </Col>
                                                                                            <Col span={2}>
                                                                                                <Button type="text" icon={<PlusOutlined />} onClick={this.addResourceC}>
                                                                                                    Add
                                                                                                </Button>
                                                                                            </Col>
                                                                                        </Row>
                                                                                    </Space>
                                                                                </>
                                                                            )}
                                                                            options={(this.state.resourcescvalues || []).map((d) => ({
                                                                                value: d.name,
                                                                                label: d.name,
                                                                            }))}
                                                                        />
                                                                    </Form.Item>
                                                                </Col>
                                                            </Row>

                                                            <div style={{ display: this.state.displaydlevel }} >
                                                                <Row>
                                                                    <Col span={6}>
                                                                        <Form.Item
                                                                            name="resourcedtype"
                                                                            label=""
                                                                            rules={[{ required: this.state.displaydlevel === 'block', message: 'Resource is required' }]}>
                                                                            <Select
                                                                                showSearch
                                                                                showArrow
                                                                                allowClear
                                                                                filterOption={(input, option) =>
                                                                                    (option?.label ?? '').toLowerCase().includes(input.toLowerCase())
                                                                                }
                                                                                onChange={this.handleChangeResourceTypeD}
                                                                                options={this.state.resourcesdlabels.map((obj) => ({
                                                                                    label: obj,
                                                                                    value: obj,
                                                                                }))}
                                                                            />
                                                                        </Form.Item>
                                                                    </Col>
                                                                    <Col span={18}>
                                                                        <Form.Item
                                                                            name="resourcedvalues"
                                                                            label=""
                                                                            rules={[{ required: this.state.displaydlevel === 'block' && this.state.selectedtypedlevel != 'none', message: 'Resource is required' }]}>
                                                                            <Select
                                                                                mode='multiple'
                                                                                showSearch
                                                                                showArrow
                                                                                allowClear
                                                                                filterOption={(input, option) =>
                                                                                    (option?.label ?? '').toLowerCase().includes(input.toLowerCase())
                                                                                }
                                                                                placeholder="Select Resource"
                                                                                dropdownRender={(menu) => (
                                                                                    <>
                                                                                        {menu}
                                                                                        <Divider style={{ margin: '8px 0', }} />
                                                                                        <Space style={{ padding: '0 8px 4px', }}>
                                                                                            <Row>
                                                                                                <Col span={22}>
                                                                                                    <Input
                                                                                                        placeholder="Please enter Resource Name"
                                                                                                        ref={this.resourcdRef}
                                                                                                        value={this.state.resourcedname}
                                                                                                        onChange={this.onResourceDChange}
                                                                                                    />
                                                                                                </Col>
                                                                                                <Col span={2}>
                                                                                                    <Button type="text" icon={<PlusOutlined />} onClick={this.addResourceD}>
                                                                                                        Add
                                                                                                    </Button>
                                                                                                </Col>
                                                                                            </Row>
                                                                                        </Space>
                                                                                    </>
                                                                                )}
                                                                                options={(this.state.resourcesdvalues || []).map((d) => ({
                                                                                    value: d.name,
                                                                                    label: d.name,
                                                                                }))}
                                                                            />
                                                                        </Form.Item>
                                                                    </Col>
                                                                </Row>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <Divider />
                                                    <Form.Item name="groups"
                                                        label={
                                                            <span>
                                                                <Space>
                                                                    Groups
                                                                    <Tooltip placement='topLeft' title="Select Groups.">
                                                                        <QuestionCircleFilled style={{ fontSize: '18px', color: 'lightblue' }} />
                                                                    </Tooltip>
                                                                    <Tooltip title="Reload groups">
                                                                        <Button
                                                                            size='small'
                                                                            type="primary"
                                                                            shape="circle"
                                                                            icon={<ReloadOutlined />}
                                                                            onClick={() => this.loadGroups()}
                                                                        />
                                                                    </Tooltip>
                                                                </Space>
                                                            </span>
                                                        }
                                                        rules={[{ required: true, message: 'Group is required' }]} className="align-left">
                                                        <Select
                                                            mode='multiple'
                                                            placeholder='Select Group.'
                                                            showSearch
                                                            showArrow
                                                            allowClear
                                                            filterOption={(input, option) =>
                                                                (option?.label ?? '').toLowerCase().includes(input.toLowerCase())
                                                            }
                                                            options={this.state.groups.map((group) => ({
                                                                label: group.name,
                                                                value: group.name,
                                                            }))}
                                                        />
                                                    </Form.Item>
                                                    <Form.Item name="roles"
                                                        label={
                                                            <span>
                                                                <Space>
                                                                    Roles
                                                                    <Tooltip placement='topLeft' title="Select Roles.">
                                                                        <QuestionCircleFilled style={{ fontSize: '18px', color: 'lightblue' }} />
                                                                    </Tooltip>
                                                                </Space>
                                                            </span>
                                                        }
                                                        rules={[{ required: true, message: 'Role is required' }]} className="align-left">
                                                        <Select
                                                            mode="multiple"
                                                            placeholder='Select Roles.'
                                                            showSearch
                                                            showArrow
                                                            allowClear
                                                            filterOption={(input, option) =>
                                                                (option?.label ?? '').toLowerCase().includes(input.toLowerCase())
                                                            }
                                                            options={this.state.accesstypes.map((role) => ({
                                                                label: role.label,
                                                                value: role.value,
                                                            }))}
                                                        />
                                                    </Form.Item>
                                                </Col>
                                                <Col span={24}>
                                                    <div style={{ textAlign: 'right' }}>
                                                        <Space>
                                                            <Button type='primary' onClick={this.handleResetForm}>Reset</Button>
                                                            <Button type='primary' htmlType='submit>'><SaveOutlined />Save</Button>
                                                        </Space>
                                                    </div>
                                                </Col>
                                            </Row>
                                        </Form>
                                    </Col>
                                </Row>
                            </Card>
                        </Col>
                    </Row>
                </Spin>
            </>
        );
    }
}

const mapStateToProps = (state) => {
    return state;
}
export default connect(mapStateToProps, null, null, { forwardRef: true })(DcpPolicyRules);