import os
from ipynb.fs.full.sparkconf  import get_spark_session
from pyspark import SparkConf
from pyspark.sql import SparkSession

os.environ['PYSPARK_SUBMIT_ARGS'] = '--packages org.apache.spark:spark-streaming-kafka-0-10_2.12:3.2.0,org.apache.spark:spark-sql-kafka-0-10_2.12:3.2.0 pyspark-shell'

conf=SparkConf()
spark = get_spark_session("consumer", conf)

KAFKA_TOPIC_NAME = "my-streaming-topi"
KAFKA_BOOTSTRAP_SERVER = "my-cluster-kafka-brokers.default.svc.cluster.local:9092"

print(conf.toDebugString())

df = spark.readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", KAFKA_BOOTSTRAP_SERVER) \
    .option("subscribe", KAFKA_TOPIC_NAME) \
    .load()

query = df.writeStream \
    .outputMode("append") \
    .format("console") \
    .start()

query.awaitTermination()

spark.stop()