import os
from ipynb.fs.full.sparkconf  import get_spark_session
from pyspark import SparkConf
from pyspark.sql import SparkSession

os.environ['PYSPARK_SUBMIT_ARGS'] = '--packages org.apache.spark:spark-streaming-kafka-0-10_2.12:3.4.2,org.apache.spark:spark-sql-kafka-0-10_2.12:3.4.2 pyspark-shell'

conf=SparkConf()
spark = get_spark_session("producer", conf)

kafka_topic="my-streaming-topi"
kafka_broker = "my-cluster-kafka-brokers.default.svc.cluster.local:9092"
kafka_properties = {
    "bootstrap.servers": kafka_broker,
    "key.serializer": "org.apache.kafka.common.serialization.StringSerializer",
    "value.serializer": "org.apache.kafka.common.serialization.StringSerializer"
}

data = [("key1", "value1"), ("key2", "value2"), ("key3", "value3")]
columns = ["key", "value"]

df = spark.createDataFrame(data, columns)

df.selectExpr("CAST(key AS STRING)", "CAST(value AS STRING)") \
    .write \
    .format("kafka") \
    .options(**kafka_properties, topic=kafka_topic) \
    .save()

# Start the Spark Streaming Query
spark.streams.awaitAnyTermination()

spark.stop()