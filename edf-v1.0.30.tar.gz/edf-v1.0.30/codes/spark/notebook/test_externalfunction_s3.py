# importer les modules une bucket s3 dans jupyterhub ex: external_functions.py
# def multiply_by_two(n):
#     return n * 2

# def concat(x):
#     return "Julie " + x
# dans sparkconf ajouetr cette ligne     "spark.submit.pyFiles": "sphs/python/external_functions.py",


from ipynb.fs.full.sparkconf  import get_spark_session
from pyspark import SparkConf
from pyspark.sql import SparkSession

conf=SparkConf()
spark = get_spark_session("externals3", conf)

import external_functions
from pyspark.sql.functions import udf
from pyspark.sql.types import IntegerType

from external_functions import multiply_by_three
multiply_by_three_udf = udf(multiply_by_three, IntegerType())

df = spark.createDataFrame([(1,), (2,), (3,)], ["number"])
df.show()

df.withColumn("number_times_three", multiply_by_three_udf("number")).show()

spark.stop()