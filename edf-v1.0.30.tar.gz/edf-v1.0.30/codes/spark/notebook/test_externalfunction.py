# importer les modules pythons dans jupyterhub ex: external_functions.py
# def multiply_by_two(n):
#     return n * 2

# def concat(x):
#     return "Julie " + x
# dans sparkconf ajouetr cette ligne     "spark.submit.pyFiles": "external_functions.py",


from ipynb.fs.full.sparkconf  import get_spark_session
from pyspark import SparkConf
from pyspark.sql import SparkSession

conf=SparkConf()
spark = get_spark_session("external", conf)

from pyspark import SparkFiles
spark_files_dir = SparkFiles.getRootDirectory()
print(spark_files_dir)

from os import environ, listdir, path
config_files = [filename
                    for filename in listdir(spark_files_dir)]


print(config_files)

df = spark.createDataFrame([(1,), (2,), (3,)], ["number"])
df.show()


import external_functions
from pyspark.sql.functions import udf
from pyspark.sql.types import IntegerType


from external_functions import multiply_by_two
multiply_by_two_udf = udf(multiply_by_two, IntegerType())


df.withColumn("number_times_two", multiply_by_two_udf("number")).show()

spark.stop()