# VERSIONS
| Service | Version |
| --- | --- |
| `Loki` | docker.io/dcptechnologies/log:loki-2.6.1 |
| `Promtail` | docker.io/dcptechnologies/log:promtail-v1 |
| `Grafana` | docker.io/dcptechnologies/log:grafana-8.3.5 |
| `Influxdb` | docker.io/dcptechnologies/log:influxdb-1.8.10 |
| `Java 17` | docker.io/dcptechnologies/java:17-jre |
| `Api` | docker.io/dcptechnologies/api:1.0.15 |
| `Proxy` | docker.io/dcptechnologies/proxy:1.0.0 |
| `Postgresql Replication` | docker.io/dcptechnologies/pgs:replication-16.1.0-debian-11-r15 |
| `Spark 334 j11 python 3 hadoop 3` | docker.io/dcptechnologies/spark:334-j11p3h3 |
| `Spark 334 j17 python 3 hadoop 3` | docker.io/dcptechnologies/spark:334-j17p3h3 |
| `Spark 342 j17 python 3 hadoop 3` | docker.io/dcptechnologies/spark:342-j17p3h3 |
| `Spark 350 j17 python 3 hadoop 3` | docker.io/dcptechnologies/spark:350-j17p3h3 |
| `Spark OP` | docker.io/dcptechnologies/spark:operator-v1beta2-1.3.8-3.1.1-1.0.0 |
| `Notebook 334 j11 python 3 hadoop 3` | docker.io/dcptechnologies/notebook:334-j11p3h3-6.2.0 |
| `Notebook 334 j17 python 3 hadoop 3` | docker.io/dcptechnologies/notebook:334-j17p3h3-6.2.0 |
| `Notebook 342 j17 python 3 hadoop 3` | docker.io/dcptechnologies/notebook:342-j17p3h3-6.2.0 |
| `Notebook 350 j17 python 3 hadoop 3` | docker.io/dcptechnologies/notebook:350-j17p3h3-6.2.0 |
| `Airflow` | docker.io/dcptechnologies/airflow:2.7.0 |
| `Airflow Load` | docker.io/dcptechnologies/airflow:sync-v1 |
| `Airflow Sync` | docker.io/dcptechnologies/airflow:dag-v1 |
| `Airflow Stats` | docker.io/dcptechnologies/airflow:statsd-v0.22.8 |
| `Airflow Prometheus` | docker.io/dcptechnologies/prometheus:v1 |
dcptechnologies/yunikorn:web-1.4.0
dcptechnologies/yunikorn:admission-1.4.0
dcptechnologies/yunikorn:scheduler-plugin-1.4.0
dcptechnologies/yunikorn:scheduler-1.4.0


dcptechnologies/sql:hms-3.1.2-v1
dcptechnologies/sql:426-v1
dcptechnologies/sql:ranger-2.4-v1
dcptechnologies/sql:audit-8.9.0-j11-v1


# (OPTIONEL)
| Service | Version |
| --- | --- |
| `OAAuthProxy` | docker.io/dcptechnologies/oauthproxy:1.0.0 |
| `Keycloak` | docker.io/dcptechnologies/keycloak:1.0.0 |
| `Postgresql H.A` | docker.io/dcptechnologies/pgs:repmgr-16.1.0-debian-11-r10 |
| `Postgresql PGPOOL` | docker.io/dcptechnologies/pgs:pgpool-4.4.5-debian-11-r0 |
| `Redis Cluster` | docker.io/dcptechnologies/redis:cluster-7.2.3-debian-11-r1 |
| `Minio` | docker.io/dcptechnologies/minio:2023.11.20-debian-11-r0 |
| `Minio Client` | docker.io/dcptechnologies/minio:client-2023.11.20-debian-11-r0 |
| `Redis Replication` | docker.io/dcptechnologies/redis:replication-7.2.3-debian-11-r1 |

# INSTALL
```sh
NAMESPACE=dcp
# Create namespace
kubectl create  ns $NAMESPACE
# Get the range UID
kubectl describe ns $NAMESPACE (openshift.io/sa.scc.uid-range: 1001020000/10000)
/Users/bassim/Downloads/oc-4.11.20-macosx/oc get project $NAMESPACE -o json | jq '.metadata.annotations."openshift.io/sa.scc.uid-range"' | cut -d "/" -f 1 | sed 's/"//g'
# infos pour créer la pullsecret (optionnel)
DOCKER_REGISTRY=docker.io
DOCKER_USERNAME=dcptechnologies
DOCKER_PASSWORD=DarkSouls2016.
DOCKER_SECRET=dcpregistry
# create the Pull Secret (Optionel)
kubectl -n $NAMESPACE create secret docker-registry $DOCKER_SECRET --docker-server=$DOCKER_REGISTRY --docker-username=$DOCKER_USERNAME --docker-password=$DOCKER_PASSWORD 
```



## DCP Installation
```sh
# La liste dess paramètres à mmodifier pour personnaliser l'installation de DCP:s

createdatabase="false" # Déployer la base de données DCP
initdatabase="false" # Initialiser la structure et les données de la base de données DCP
createdcpapi="false" # Déployer DCP (API & UI)
enabledcpproxy="true" # Déployer le dcp proxy utile pour générer les spark UIs.
createdcpscheduler="false" # Déployer le scheduler DCP
enabledcpstorage="false" # Déployer minio (Optionnel)
enabledcpredis="false" # Déployer Redis, pré-requis pour l'utilisation de la gateway DCP Sql et DCP IDP/SDP
enablelogstack="false" # Déployer la stack DCP logging
createdcpgrafana="true" # Déployer grafana pour la consultation des logs.


#GLOBAL
ISOPENSHIFT=true # true si le déploiement se fera sur un openshift
REGISTRY= # la registry privée par défault pour la récupération des images 
REPOSITORY= # le repo docker par défaut
PULLPOLICY=IfNotPresent #stratégir de récupération des images: IfNotPresent, Always, Never
IMAGEPULLSECRET= # le nom de la secret qui contient les crédentials pour s'authentifier à la registry docker
NINXCLASS=nginx # le nom de la class ingress du cluster kubenetes, elle ne sera pas utile si on force l'utilisaation des routes openshift à la place de l'operator ingress
USEINGRESSCLASSNAME=false # mettre à true pour une version kubernetes >= 1.28
NAMESPACE= # namespoce dédié pour le module DCP et ses composants.
STORAGECLASSNAME= # la classe de stockage par défaut de type RWO.
ENABLEOSROOT=true # true: forcer l'utilisation des routes : recommaandé pour un cluster openshift.
ENABLEINGRESS=false # true forcer l'utilisation de l'operator ingress
DOMAIN= # Domain name
INGRESSHOSTNAME=dcp.$DOMAIN # l'url dédiée à la plateforme DCP.
RUNASUSER= # USER ID pour les container de la plateforme DCP.

#LDAP
# Saisir la section LDAP dans le script.

# RBAC
# il est possible de déployer DCP pour piloter plusieurs NAMESPACES ou un ensemble fixe de namespaces.
MASTER_CLUSTER_ROLE= # true: dcp peut créer de déployer des assets dans ces nammespaces. false: dcp ne peut déployer que dans la liste des namespaces définie dans la variable MASTER_NAMESPACES
#MASTER_NAMESPACES="\n    - dcp\n    - ns1\n    - ns2\n    - ns3"
PODWATCHER_CLEANPODS=true # Supprimer les pods spark une fois que le job se termine avec un status success
PODWATCHER_NAMESPACES="" # limiter la surveillance des namespaces où se lanceront les spark jobs.
#PODWATCHER_NAMESPACES="ns1,ns2,ns3"


```

# Certificats 
```
Pour que DCP puisse se connecter à LDAP et éventuellement un stockage S3 en mode SSL:
  - Récupérer les certificats ldap & s3. 
  - Créer un fichier par certificaat avec son contenu dans le répertoire $pwd/scripts/repos/master-api/files
  - Renseigner les noms de ces fichiers dans la variable "MASTER_EXTRAS_FILES" dans le script d'installation

```

# Déploiement
```
  -  pour lancer l'installation, lancer le script install-with-logstack.sh.
  -  se connecter à l'IHM de DCP, aller dans le menu "Admin->Kubernetes" puis editer la conf    
     "local->Spark->Spark Job":
      1. Activer Enable Spark Config
      2. copier le contenu du fichier $pwd/post-install/spark.jinja2 dans le champ Spark Job Config
```

# 





openssl s_client -showcerts -servername masterxhwnikmfe7.apps.rhodcp01.cz0z.p1.openshiftapps.com -connect masterxhwnikmfe7.apps.rhodcp01.cz0z.p1.openshiftapps.com:443 2>/dev/null </dev/null | sed -ne '/-BEGIN CERTIFICATE-/,/-END CERTIFICATE-/p'
