1. Namespace

2. Parameters
PREFIX=dcp
# section GLOBAL
# sectioon LDAP
# section TOPOLOGY
# section LOG
- LOKI_PERSISSTENCE_ENABLED
# section DCP SCHEDULER
- SCHEDULER_GLOBAL_VERSION=1.5.0
# sectioon DATABASE
- PGS_REPLICATION_ARCHITECTURE
- PGS_REPLICATION_REPLICACOUNT
- ajuster les resources

# section DCPAPI
- MASTER_LOGLEVEL
- MASTER_REPLICAS
- MASTER_SHARED_SIZE
- MASTER_SHARED_STORAGECLASSNAME
- MASTER_SHARED_STORAGECLASSANNOTATION
- MASTER_WORK_SIZE
- MASTER_EXTRAS_FILES
- MASTER_XMS
- MASTER_XMX
- Ajuster les resources

3. copier les certificats ldap et storage dans le dossier "dcp-setup/scripts/repos/master-api/files" (ldap.crt, storage.crt)

# section LOG WATCHER
- LOGWATCHER_REPLICAS
- LOGWATCHER_LOGLEVEL
- Ajuster les resources

# section POD WATCHER
- PODWATCHER_LOGLEVEL
- Ajuster les resources

# section HEALTH SERVICE
- HEALTH_LOGLEVEL
- HEALTH_REPLICAS
- Ajuster les resources

# section SQL ACTIVITY
- SQLACTIVITY_LOGLEVEL
- SQLACTIVITY_REPLICAS=1
- Ajuster les resources

# section redis cluster
- REDIS_REPLICATION_ARCHITECTURE=standalone / replication
- Ajuster les resources

# section PROXY
- Ajuster les resources


# Installation
execute the first time
./02-secrets.sh
./gen-certs.sh

./create-secret.sh
./05-scheduler.sh
./06-proxy.sh
./07-database.sh
./08-initdatabase.sh
./09-api.sh
aller dans le menu Admin->Kubernetes->Spark->spark Job et coller le contenu de spark config
./10-logwatcher.sh
./11-podwatcher.sh primary
./11-podwatcher.sh secondary
./11-podwatcher.sh backup
./12-health.sh
./13-sqlactivity.sh



java:21-jre
java:17-jre
java:11-jre
yunikorn:scheduler-1.5.0
yunikorn:scheduler-plugin-1.5.0
yunikorn:admission-1.5.0
yunikorn:web-1.5.0
redis:cluster-7.2.3-debian-11-r1
redis:replication-7.2.3-debian-11-r1
log:box-v1
curl:v1
log:grafana-8.3.5
log:influxdb-1.8.10
log:loki-2.6.1
log:promtail-v1
api:1.0.30
logwatcher:1.0.30
podwatcher:1.0.30
health:1.0.30
sqlactivity:1.0.30
proxy:1.0.0
oauthproxy:1.0.0
keycloak:21.1.2-debian-11-r27

airflow:2.7.0
airflow:2.9.0
airflow:sync-v1
airflow:dag-v1
airflow:statsd-v0.22.8
prometheus:v1

sql:hms-3.1.2-v1
sql:433-cache-v1
sql:443-v1
sql:policy-1.0.0
sql:prestodb-286
sql:dbeaver-21.3.0

cache:2.10.0-SNAPSHOT


spark:350-j17p3h3
spark:342-j17p3h3
spark:334-j17p3h3
spark:334-j11p3h3

notebook:350-j17p3h3-6.2.0
notebook:342-j17p3h3-6.2.0
notebook:334-j17p3h3-6.2.0
notebook:334-j11p3h3-6.2.0